<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Doctor's Directory Request</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="{{url("/css/mail.css")}}">
</head>
<body id="usuario">
	<div class="container">
        <div class="logo">
            <img src="{{$message->embed(public_path() . "/img/mail-logo.jpg")}}" alt="">
        </div>
	</div>
</body>
</html>
