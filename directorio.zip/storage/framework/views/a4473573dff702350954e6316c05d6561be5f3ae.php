<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/bootstrap.min.css">
<style>
    .Content .search-bar .container .row .column form fieldset:nth-child(3):before, .Content .search-bar .container .row .column form fieldset:nth-child(3):after{
        display: none;
    }
    div.error {
        color: #ff0000;
    }
</style>
<div class="search-bar">
            <div class="container">
                <div class="row">
                    <?php if(session()->has('success')): ?>
                        <div class="horizontal-center alert alert-success text-center"> 
                            <?php echo session('success'); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('message.level')): ?>
                    <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                        <?php echo session('message.content'); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($errors->has('delete')): ?>
                    <div class="alert alert-danger">
                        <strong><?php echo e($errors->first('delete')); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($errors->has('error')): ?>
                    <div class="alert alert-danger">
                        <strong><?php echo e($errors->first('error')); ?></strong>
                    </div>
                    <?php endif; ?>
                    <div class="column">
                        <form action="<?php echo e(route('forgetpasswordSendLink')); ?>" method="post" autocomplete="off" novalidate="" style="text-align:center; " onsubmit="return chkField();" >
                            <?php echo csrf_field(); ?>
                            <fieldset>
                                Email Address : <br><br> <input name="email" id="email" type="email" placeholder="" autocomplete="off" value="<?php echo e(old('email')); ?>">
                            </fieldset>
                            <div class="error"><?php echo e($errors->first('email')); ?>

                                <?php if(session()->has('error')): ?>
                                    <?php echo session('error'); ?>

                                <?php endif; ?>
                            </div>
                            <fieldset>
                                <button type="submit" name="submit"  id="searchBtn">Enviar</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

<script>
    function chkField() {
        var getEmail = $('#email').val();
        if(getEmail == ''){
            $('#email').focus();
            return false;
        }
        return true;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>