<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/sb-admin.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.user.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <div class="content-wrapper">
        <div class="container-fluid overflow-hidden">
            <div class="row margin-bottom-90px margin-lr-10px sm-mrl-0px">
                <!-- Page Title -->
                <div id="page-title" class="padding-30px background-white full-width">
                    <div class="container">
                        <ol class="breadcrumb opacity-5">
                            <li><a href="#"><?php echo app('translator')->getFromJson('labels.home'); ?></a></li>
                            <li><a href="#"><?php echo app('translator')->getFromJson('labels.dashboard'); ?></a></li>
                            <li class="active"><?php echo app('translator')->getFromJson('labels.my_profile'); ?></li>
                        </ol>
                        <h1 class="font-weight-300"><?php echo app('translator')->getFromJson('labels.my_profile'); ?></h1>
                    </div>
                </div>
                <!-- // Page Title -->
                <form action="<?php echo e(route('user.updateprofiledetails')); ?>" method="post" name="editprofile" id="editprofile" enctype="multipart/form-data">
                <div class="row margin-tb-45px full-width">
                    <?php if(session()->has('message.level')): ?>
                    <div class="col-md-12 horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <?php echo session('message.content'); ?>

                    </div>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="col-md-4">
                        <div class="padding-15px background-white">
                            <a href="javascript:voide(0)" id="imageContainer" class="d-block margin-bottom-10px">
                                <?php if($userdetails->image): ?>
                                <img id="imgUserimage" src="<?php echo e(asset('public/uploads/userimage/'.$userdetails->id.'/'.$userdetails->image )); ?>" alt=""></a>
                                <?php else: ?>
                                <img id="imgUserimage" src="<?php echo e(asset('public/front')); ?>/assets/images/blank-profile-picture.png" alt=""></a>
                                <?php endif; ?>
                                <!-- <img id="imgUserimage" src="<?php echo e(asset('public/front')); ?>/assets/images/blank-profile-picture.png" alt=""></a> -->
                            <div class="error text-center">(max size: 5 mb)</div>
                            <input  accept="image/x-png,image/gif,image/jpeg" type="file" name="profilepic" id="profilepic"  class="btn btn-sm  text-white background-main-color btn-block"><?php echo app('translator')->getFromJson('labels.upload_image'); ?></a>

                            <div class="error"><?php echo e($errors->first('profilepic')); ?></div>
                        </div>
                    </div>
                    <div class="col-md-8">
                      <div class="row">
                          <div class="col-md-6 margin-bottom-20px">
                              <label><i class="far fa-user margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.fullname'); ?> <sup class="requiredSup">*</sup></label>
                              <input type="text" class="form-control form-control-sm" name="fullname" id="fullname" placeholder="<?php echo app('translator')->getFromJson('labels.fullname'); ?>" required value="<?php echo e($userdetails->name); ?>" minlength="3" maxlength="25">
                              <div class="error"><?php echo e($errors->first('fullname')); ?></div>
                          </div>
                          
                          <div class="col-md-6 margin-bottom-20px">
                              <label><i class="far fa-envelope-open margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.email'); ?></label>
                              <input type="text" class="form-control form-control-sm" placeholder="<?php echo app('translator')->getFromJson('labels.email'); ?>" readonly value="<?php echo e($userdetails->email); ?>">
                          </div>
                          <div class="col-md-6 margin-bottom-20px">
                              <label><i class="fas fa-mobile-alt margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.phone'); ?> <sup class="requiredSup">*</sup></label>
                              <input type="text" class="form-control form-control-sm" placeholder="<?php echo app('translator')->getFromJson('labels.phone'); ?>" name="phone" id="phone" required value="<?php echo e($userdetails->phone); ?>" maxlength="15">
                          </div>
                          <div class="col-md-6">
                              <label><i class="fas fa-link margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.website'); ?></label>
                              <input type="text" class="form-control form-control-sm" placeholder="www.your-site.com" name="website" id="website" value="<?php echo e($userdetails->website); ?>" url="true" >
                          </div>
                          <div class="col-md-6">
                              <label><i class="fas fa-info margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.description'); ?> <sup class="requiredSup">*</sup></label>
                              <textarea class="form-control form-control-sm" name="description" id="description" placeholder="<?php echo app('translator')->getFromJson('labels.description'); ?>" required minlength="20" ><?php echo e($userdetails->description); ?></textarea>
                          </div>
                          <div class="col-md-6">
                              <label><i class="fas fa-info margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.specialization'); ?> <sup class="requiredSup">*</sup></label>
                              <textarea class="form-control form-control-sm" name="specialization" id="specialization" required="" placeholder="<?php echo app('translator')->getFromJson('labels.specialization'); ?>" ><?php echo e($userdetails->specialization); ?></textarea>
                          </div>
                          <div class="col-md-6">
                              <label><i class="fas fa-info margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.about_yourself'); ?> <sup class="requiredSup">*</sup></label>
                              <textarea class="form-control form-control-sm" name="about" id="about" placeholder="About yourself.." required minlength="20" ><?php echo e($userdetails->about); ?></textarea>
                          </div>
                      </div>
                      <hr class="margin-tb-40px">
                      
                        <div class="row">
                            <label><i class="fas fa-info margin-right-10px"></i> <?php echo app('translator')->getFromJson('labels.available_timings'); ?></label>
                            <table class="table table-striped">
                                <tr>
                                    <td><?php echo app('translator')->getFromJson('labels.available_for_day'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('labels.day'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('labels.from_time'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('labels.to_time'); ?></td>
                                </tr>
                                <?php
                                $daysArr = array('mon' => __('labels.monday'), 'tue'  => __('labels.tuesday'), 'wed' => __('labels.wednesday'), 'thu'  => __('labels.thursday'), 'fri' => __('labels.friday'), 'sat' => __('labels.saturday'), 'sun' => __('labels.sunday'));

                                

                                foreach ($daysArr as $key => $value) {
                                    $start = '12:00AM';
                                    $end = '11:59PM';
                                    $interval = '+ 15 minutes';

                                    $start_str = strtotime($start);
                                    $end_str = strtotime($end);
                                    $now_str = $start_str;

                                    $getUserTimings = $usertimings->{$key.'Timing'};
                                    $getUserTimings = ($getUserTimings) ? explode('-', $getUserTimings): '';

                                    ?>
                                    <tr>
                                        <td><input type="checkbox" name="<?php echo $key;?>AvailableStatus" id="monAvailableStatus" <?php echo ($usertimings->{$key.'Status'}) ? 'checked':''; ?> ></td>
                                        <td><?php echo $value;?></td>
                                        <td>
                                            <select class="form-control-sm" name="<?php echo $key;?>Fromtime" id="<?php echo $key;?>Fromtime">
                                                <?php 

                                                while($now_str <= $end_str){
                                                    $fromTime = date('h:i A', $now_str);
                                                    $selectedFrom = '';
                                                    if($getUserTimings && $getUserTimings[0] == $fromTime){
                                                        $selectedFrom = 'selected="selected"';
                                                    }
                                                    echo '<option   '.$selectedFrom.' value="' . $fromTime . '">' . $fromTime . '</option>';
                                                    $now_str = strtotime($interval, $now_str);
                                                }
                                                ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control-sm" name="<?php echo $key;?>Totime" id="<?php echo $key;?>Totime">
                                                <?php 
                                                $now_str = $start_str;
                                                while($now_str <= $end_str){
                                                    $toTime = date('h:i A', $now_str);
                                                    $selectedTo = '';
                                                    if($getUserTimings && $getUserTimings[1] == $toTime){
                                                        $selectedTo = 'selected="selected"';
                                                    }
                                                    echo '<option '.$selectedTo.' value="' . $toTime . '">' . $toTime . '</option>';
                                                    $now_str = strtotime($interval, $now_str);
                                                }
                                                ?>
                                            </select>
                                        </td>
                                    </tr>    
                                <?php }
                                ?>
                                
                            </table>
                        </div>
                      
                      <button class="btn btn-md padding-lr-25px  text-white background-main-color btn-inline-block" type="submit" name="submit" id="submit"><?php echo app('translator')->getFromJson('labels.update_profile'); ?></button>

                    </div>
                </div>
                </form>

            </div>
        </div>
        <!-- /.container-fluid-->
        <!-- /.content-wrapper-->
        <footer class="sticky-footer">
            <div class="container">
                <div class="text-center">
                    <span><?php echo app('translator')->getFromJson('labels.footer_copyright'); ?></span>
                </div>
            </div>
        </footer>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
          <i class="fa fa-angle-up"></i>
        </a>
        <!-- Logout Modal-->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="page-login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function(){
        $('#editprofile').validate();
    });
    function readImgURL(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e) {
          $('#imgUserimage').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#profilepic").change(function() {
      readImgURL(this);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>