<?php $__env->startSection('content'); ?>
<div id="slider">
<div class="slider_inner">
<div class="slider_inner2">
    
<ul id="carousel1" class="clearfix">
    <li>
        <div class="txt1">
            It's quick survey
        </div>
        <div class="txt2">
            We offer profitable and successful solutions
        </div>
        <div class="txt3">
            Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et <br>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
        </div>
    </li>
    <li>
        <div class="txt1">
            It works
        </div>
        <div class="txt2">
            Offering simple, smart and professional solutions.
        </div>
        <div class="txt3">
            Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et <br>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
        </div>
    </li>
    <li>
        <div class="txt1">
            It's easy
        </div>
        <div class="txt2">
            Good support for your business!
        </div>
        <div class="txt3">
            Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et <br>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
        </div>
    </li>
    <li>
        <div class="txt1">
            It's smart
        </div>
        <div class="txt2">
            We know how to help you!
        </div>
        <div class="txt3">
            Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et <br>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
        </div>
    </li>       
</ul>       
    
        <a class="prev" href="#"></a>
        <a class="next" href="#"></a>
    </div>  
</div>
</div>  

<div class="banners">
<div class="container">
<div class="row">
    <div class="span3 banner banner1">
        <div class="thumb-banner1">
            <div class="thumbnail clearfix">
                <figure><img src="<?php echo e(asset('public/front/')); ?>/images/banner1.png" alt=""></figure>
                <div class="caption">
                    <div class="txt1">
                        How It Works
                    </div>
                    <div class="txt2">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.
                    </div>
                    <a href="#" class="button0">Details</a>
                </div>
            </div>
        </div>
    </div>
    <div class="span3 banner banner2">
        <div class="thumb-banner1">
            <div class="thumbnail clearfix">
                <figure><img src="<?php echo e(asset('public/front/')); ?>/images/banner2.png" alt=""></figure>
                <div class="caption">
                    <div class="txt1">
                        What We Do
                    </div>
                    <div class="txt2">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.
                    </div>
                    <a href="#" class="button0">Details</a>
                </div>
            </div>
        </div>
    </div>
    <div class="span3 banner banner3">
        <div class="thumb-banner1">
            <div class="thumbnail clearfix">
                <figure><img src="<?php echo e(asset('public/front/')); ?>/images/banner3.png" alt=""></figure>
                <div class="caption">
                    <div class="txt1">
                        Support
                    </div>
                    <div class="txt2">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.
                    </div>
                    <a href="#" class="button0">Details</a>
                </div>
            </div>
        </div>
    </div>
    <div class="span3 banner banner4">
        <div class="thumb-banner1">
            <div class="thumbnail clearfix">
                <figure><img src="<?php echo e(asset('public/front/')); ?>/images/banner4.png" alt=""></figure>
                <div class="caption">
                    <div class="txt1">
                        Solutions
                    </div>
                    <div class="txt2">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.
                    </div>
                    <a href="#" class="button0">Details</a>
                </div>
            </div>
        </div>
    </div>
</div>  
</div>
</div>

<div id="content">
<div class="container">
<div class="row">
    <div class="span9">

        <h1>Welcome to Altus Group</h1>
        <p>
            Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat consectetuer adipiscing elit. Nunc suscipit. Suspendisse enim arcu, convallis non, cursus sed, dignissim et, est. Aenean semper aliquet libero. In ante velit, cursus ut, ultrices vitae, tempor ut, risus. Duis pulvinar. Vestibulum vel pede at sapien sodales mattis. Quisque pretium, lacus nec iaculis vehicula, arcu libero consectetuer massa, auctor aliquet mauris ligula id ipsum. Vestibulum pede. Maecenas sit amet augue. Sed blandit lect
        </p>

        <h5>
            Curabitur nibh lectus, dapibus id, tempor eu, tempor non, erat. Proin pede eros, pharetra ut, viverra sed, egestas nec, mauris. Nulla tempor fermentum orci.
        </h5>

        <div class="thumb1">
            <div class="thumbnail clearfix">
                <figure><img src="<?php echo e(asset('public/front/')); ?>/images/home01.jpg" alt=""></figure>
                <div class="caption">
                    <p>
                        Curabitur convallis interdum erat. Proin feugiat sem eu nisl. Aliquam erat volutpat. Fusce a mauris vel nulla faucibus tempor. Aenean scelerisque neque aliquam nibh venenatis molestie. Integer gravida ornare lectus. Nunc vehicula elit a tellus. Nunc est ipsum, facilisis at, auctor tincidunt, adipiscing consequat, orci. Fusce pellentesque. Proin lorem. Mauris suscipit erat a turpis. Nunc mollis lectus in dolor. Curabitur velit. Curabitur commodo vestibulum justo. Praesent dictum, est ut porta adipiscing, ligula mi ultricies velit, non hendrerit mi augue id eros. Nulla mauris purus, dignissim a, eleifend ac,
                    </p>                    
                </div>
            </div>
        </div>





    </div>
    <div class="span3">

        <h4>Services</h4>

        <div class="accordion" id="accordion1">
            <div class="accordion-group">
                <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse1">
                        Lorem ipsum dolor sit
                    </a>
                </div>
                <div id="collapse1" class="accordion-body collapse in">
                    <div class="accordion-inner">
                        <i class="color1">Nulla tempor</i><br>Curabitur convallis interdum erat. Proin feugiat sem eu nisl. Aliquam erat volutpat.
                    </div>
                </div>
            </div>
            <div class="accordion-group">
                <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse2">
                        Amet consectr adi
                    </a>
                </div>
                <div id="collapse2" class="accordion-body collapse">
                    <div class="accordion-inner">
                        Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                </div>
            </div>
            <div class="accordion-group">
                <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse3">
                        Praesent vestibulum
                    </a>
                </div>
                <div id="collapse3" class="accordion-body collapse">
                    <div class="accordion-inner">
                        Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                </div>
            </div>
            <div class="accordion-group">
                <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse4">
                        Fusce suscipit
                    </a>
                </div>
                <div id="collapse4" class="accordion-body collapse">
                    <div class="accordion-inner">
                        Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                </div>
            </div>
            <div class="accordion-group">
                <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse5">
                        Phasellus accumsan
                    </a>
                </div>
                <div id="collapse5" class="accordion-body collapse">
                    <div class="accordion-inner">
                        Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                </div>
            </div>
            
        </div>





    </div>

</div>  

<div class="hl1"></div>

<div class="row">
<div class="span9 text-right">
    <h3>It's time to improve your business today!</h3>

    <h6>Making the sale is only the beginning: you want to establish a real bond with your customers that keeps them coming back.</h6>

    <p>
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpatorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam n onummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
    </p>
    <a href="#" class="button0">Details</a>
</div>
<div class="span3">
    <div class="thumb-clock">
        <div class="thumbnail clearfix">
            <figure><img src="<?php echo e(asset('public/front/')); ?>/images/clock1.jpg" alt=""></figure>           
        </div>
    </div>
</div>  
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>