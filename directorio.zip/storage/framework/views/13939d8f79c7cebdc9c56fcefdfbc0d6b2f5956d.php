<!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-dark z-index-9  fixed-top" id="mainNav">

        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav navbar-sidenav background-main-color admin-nav" id="admin-nav">
                <li class="nav-item">
                    <span class="nav-title-text">Main</span>
                </li>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
                    <a class="nav-link <?php echo e((Request::is('mydashboard') ? 'active' : '')); ?>" href="<?php echo e(url('/mydashboard')); ?>">
                        <i class="fas fa-fw fa-home"></i><span class="nav-link-text">Dashboard</span>
                    </a>
                </li>
                
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Reviews">
                    <a class="nav-link <?php echo e((Request::is('mydashboard/my-reviews') ? 'active' : '')); ?>" href="<?php echo e(url('mydashboard/my-reviews')); ?>">
                    <i class="fa fa-fw fa-star"></i>
                    <span class="nav-link-text">Reviews -  By me</span>
                    </a>
                </li>
                <?php if(Auth::user()->type == 2 || Auth::user()->type == 3): ?>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Reviews">
                    <a class="nav-link <?php echo e((Request::is('mydashboard/my-reviews/to-me') ? 'active' : '')); ?>" href="<?php echo e(url('mydashboard/my-reviews/to-me')); ?>">
                    <i class="fa fa-fw fa-star"></i>
                    <span class="nav-link-text">Reviews -  To me</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <span class="nav-title-text">User Area</span>
                </li>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="My Profile">
                    <a class="nav-link <?php echo e((Request::is('mydashboard/my-profile') ? 'active' : '')); ?>" href="<?php echo e(url('mydashboard/my-profile')); ?>">
                        <i class="fa fa-fw fa-user-circle"></i>
                        <span class="nav-link-text">My Profile</span>
                    </a>
                </li>
                <?php if(Auth::user()->type == 2 || Auth::user()->type == 3): ?>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="My Location">
                    <a class="nav-link <?php echo e((Request::is('mydashboard/my-location') ? 'active' : '')); ?>" href="<?php echo e(url('profile/'.Auth::user()->userslug)); ?>" target="_blank">
                        <i class="fa fa-fw fa-user"></i>
                        <span class="nav-link-text">Visit My Profile</span>
                    </a>
                </li>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="My Location">
                    <a class="nav-link <?php echo e((Request::is('mydashboard/my-location') ? 'active' : '')); ?>" href="<?php echo e(url('mydashboard/my-location')); ?>">
                        <i class="fa fa-fw fa-map-marker"></i>
                        <span class="nav-link-text">My Location</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Sing Out">
                    <a class="nav-link" href="<?php echo e(url('mydashboard/change-password')); ?>" >
                        <i class="fa fa-fw fa-sign-out-alt"></i>
                        <span class="nav-link-text">Change Password</span>
                    </a>
                </li>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Sing Out">
                    <a class="nav-link" href="<?php echo e(url('logout')); ?>" >
                        <i class="fa fa-fw fa-sign-out-alt"></i>
                        <span class="nav-link-text">Sing Out</span>
                    </a>
                </li>
            </ul>




        </div>
    </nav>
    <?php if( Auth::user()->address == '' && (Auth::user()->type == 2 || Auth::user()->type == 3)): ?>
    <div class="content-wrapper" style="margin-bottom: 10px;min-height: 50px;">
        <div class="alert alert-warning">Please add your location and address, so that your profile could be searched by users. <a href="<?php echo e(url('mydashboard/my-location')); ?>">Click here</a></div>
    </div>
    <?php endif; ?>