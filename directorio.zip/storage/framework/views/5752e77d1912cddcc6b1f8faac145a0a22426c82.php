<?php $__env->startSection('pagecontent'); ?>

<div class="page-title">
	<div class="title_left">
	  <h3>Add new poll</h3>
	</div>
</div>
<div class="clearfix"></div>
<!--
<?php if(count($errors) > 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="horizontal-center alert alert-danger alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php echo e($error); ?>

</div>
<?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
-->

<?php if(session()->has('message.level')): ?>
<div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <?php echo session('message.content'); ?>

</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Poll details update </h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <br />
          <form id="demo-form2" method="POST" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(url('admin/poll/'.$polldata->id)); ?>">
          	<input name="_method" type="hidden" value="PUT">
          	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Poll Subject <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<input type="text" id="first-name" required="required" value="<?php echo e($polldata->poll_subject); ?>" class="form-control col-md-7 col-xs-12" name="subject">
					<div class="error"><?php echo e($errors->first('subject')); ?></div>
	            </div>

            </div>
            
            <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Poll Options 1 <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<input type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" name="option1" value="<?php echo e($polloptions[0]->poll_option); ?>">
					<input type="hidden" name="option1_dbId" value="<?php echo e($polloptions[0]->id); ?>">
					<div class="error"><?php echo e($errors->first('option1')); ?></div>
	            </div>
            </div>
            <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Poll Options 2 <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<input type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" name="option2" value="<?php echo e($polloptions[1]->poll_option); ?>">
					<input type="hidden" name="option2_dbId" value="<?php echo e($polloptions[1]->id); ?>">
					<div class="error"><?php echo e($errors->first('option2')); ?></div>
	            </div>
            </div>
            <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Poll Options 3 <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<input type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" name="option3" value="<?php echo e($polloptions[2]->poll_option); ?>">
					<input type="hidden" name="option3_dbId" value="<?php echo e($polloptions[2]->id); ?>">
					<div class="error"><?php echo e($errors->first('option3')); ?></div>
	            </div>
            </div>
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Poll Options 4<span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<input type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" name="option4" value="<?php echo e($polloptions[3]->poll_option); ?>">
					<input type="hidden" name="option4_dbId" value="<?php echo e($polloptions[3]->id); ?>">
					<div class="error"><?php echo e($errors->first('option4')); ?></div>
	            </div>
            </div>

            <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success">Update</button>
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>