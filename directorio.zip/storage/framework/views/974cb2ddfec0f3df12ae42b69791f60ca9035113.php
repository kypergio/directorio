<style type="text/css">
    .myoption{ 
        border: 1px solid #cccccc;
        height: 24px;
        padding: 3px;
        margin-top: 2%;
    }
</style>



<?php $__env->startSection('pagecontent'); ?>
<?php
$title = "Add Status";
$action = route('status.store');
$method = "";
$image = "";
$button = 'Add Status';
if (!empty($ticket_status->id)) {

//    echo '<pre>';
//    print_r($ticket_data);die;

    $title = "Edit Status";
    $action = route('status.update', $ticket_status->id);
    $method = '<input type="hidden" name="_method" value="PUT" />';
    $button = 'Update Ticket';
}
?>


<div class="right_col" role="main" style="min-height: 3214px;">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><span><?php echo $title; ?></span><small></small></h3>
            </div>
            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search"></div>
            </div>
        </div>
        <div class="clearfix"></div>

        <?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="horizontal-center alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e($error); ?>

        </div>
        <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(session()->has('message.level')): ?>
        <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <?php echo session('message.content'); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <form method="post" action="<?php echo e($action); ?>" id="demo-form2" class="form-horizontal form-label-left" enctype="multipart/form-data">
            <?php echo $method; ?>

            <div class="col-md-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <h2>Status <small>details</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status_name">Status Name
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" id="status_name" name="status_name" placeholder="Status Name"   class="form-control col-md-7 col-xs-12" value="<?php echo e(!empty($ticket_status->status_name)?$ticket_status->status_name:Input::old('status_name')); ?>">
                            </div>
                        </div>
                    </div>
                </div>



                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="ln_solid"></div>
                <div class="form-group">
                    <div class="col-md-12 col-xs-12">
                        <button style="margin: 0 0 0 46%" type="submit" class="btn btn-success"><?php echo $button; ?></button>
                    </div>
                </div>
        </form>

    </div>
</div>
</div>    
 
<script src="<?php echo e(asset('resources/assets/gentelella/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/assets/gentelella/vendors/datatables.net-bs/js/dataTables.bootstrap.js')); ?>"></script>
<!--<script src="<?php echo e(asset('../resources/assets/gentelella/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('../resources/assets/gentelella/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?>">
    
</script>-->
<script src="<?php echo e(asset('resources/assets/gentelella/vendors/bootbox/bootbox.min.js')); ?>" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.0.11/handlebars.min.js"></script>
<?php echo $__env->make('admin.status.more_details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript">
var dataTable;
var columns = [
    {data: 'rownum', name: 'rownum'},
    {data: 'id', name: 'id'},
    {data: 'poll_subject', name: 'poll_subject'},
    {data: 'created_at', name: 'created_at'},
    {data: 'action', name: 'action'},
];
var template = Handlebars.compile($("#details-template").html());
var ajaxUrl = '<?php echo route('poll.index'); ?>'; //Url of ajax datatable where you fetch data

//It may be empty array
var columnDefs = [
    {
        "targets": 0,
        "orderable": true,
        "class": "text-center",
    },
    {
        "targets": 1,
        "orderable": true,
        "class": "text-left"
    },
    {
        "targets": 2,
        "orderable": true,
        "class": "text-center"
    },
    {
        "targets": 3,
        "orderable": true,
        "class": "text-center"
    },
    {
        "targets": 4,
        "orderable": false,
        "class": "text-center"
    },
            /*{
             "targets": 5,
             "orderable": false,
             "class":"text-center"
             },*/
];
//var columnDefs = [];
</script> 

<script type="text/javascript">
    $(document).ready(function () {
        $(document).on('click', '.more-details', function () {
            var tr = $(this).closest('tr');
            var row = dataTable.row(tr).data();
            $('#myModalHorizontal .modal-body').html(template(row));
            $('#myModalHorizontal ').modal('show');
        });
    });
</script> 
<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>