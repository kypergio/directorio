<?php $__env->startSection('content'); ?>
<style>
    .rateUser ul li {
        width: 20px;height:20px;background-size:cover;
    }
</style>
<?php if(session()->has('message.level')): ?>
<div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <?php echo session('message.content'); ?>

</div>
<?php endif; ?>
<div id="page-title" class="padding-tb-30px gradient-white hide">
        <div class="container">
            <h1 class="font-weight-300"><?php echo e(ucwords($userdetails->name)); ?></h1>
        </div>
    </div>


    <div class="margin-bottom-30px">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">

                    <div class="margin-bottom-30px box-shadow">
                        <?php if($userdetails->image): ?>
                        <img src="<?php echo e(asset('public/uploads/userimage/').'/'.$userdetails->id.'/'.$userdetails->image); ?>" alt="<?php echo e($userdetails->name); ?>">
                        <?php else: ?>
                        <img src="<?php echo e(asset('public/front/assets/images')); ?>/no-profile-image-min.jpg" alt="<?php echo e($userdetails->name); ?>">
                        <?php endif; ?>
                        
                        <div class="padding-30px background-white">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="rating clearfix">
                                        <span class="float-left text-grey-2"><i class="far fa-map"></i>  <?php echo e(ucfirst($userdetails->address)); ?></span>
                                        <ul class="float-right">
                                            <li class="active"></li>
                                            <li class="active"></li>
                                            <li class="active"></li>
                                            <li class="active"></li>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row no-gutters">
                                        <div class="col-6"><a href="#" class="text-lime"><i class="far fa-bookmark"></i> Open Now!</a></div>
                                        <!-- <div class="col-4 text-center"><a href="#" class="text-red"><i class="far fa-heart"></i> Save</a></div> -->
                                        <div class="col-6 text-right"><a href="#" class="text-blue"><i class="far fa-hospital"></i> <?php echo e($userdetails->categorytype); ?></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="margin-bottom-30px box-shadow">
                        <div class="padding-30px background-white">
                            <h3><i class="far fa-hospital margin-right-10px text-main-color"></i> About - <?php echo e(ucfirst($userdetails->name)); ?></h3>
                            <hr>
                            <p class="text-grey-2"><?php echo e(ucfirst($userdetails->about)); ?></p>
                            <p class="text-grey-2"><?php echo e(ucfirst($userdetails->description)); ?></p>
                        </div>
                    </div>

                    <div class="margin-bottom-30px box-shadow">
                        <div class="padding-30px background-white">
                            <h3><i class="far fa-map margin-right-10px text-main-color"></i> <?php echo e(ucfirst($userdetails->name)); ?> Location</h3>
                            <hr>
                            <div class="map-distributors-in">
                                <div id="map_canvas" style="width: 100%;height:250px;"></div>
                            </div>
                        </div>
                    </div>

                    <div class="margin-bottom-30px box-shadow">
                        <div class="padding-30px background-white">
                            <h3><i class="far fa-star margin-right-10px text-main-color"></i> Review &amp; Rating</h3>
                            <hr>
                        
                            <ul class="commentlist padding-0px margin-0px list-unstyled text-grey-3">
                                
                                <?php $__empty_1 = true; $__currentLoopData = $ratingDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="border-bottom-1 border-grey-1 margin-bottom-20px">
                                        <?php if($rating->image): ?>
                                        <img style="width: 60px;height: 60px;" src="<?php echo e(asset('public/uploads/userimage'.'/'.$rating->fromuserid.'/'.$rating->image)); ?>" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                        <?php else: ?>
                                        <img style="width: 60px;height: 60px;" src="<?php echo e(asset('public/front/assets/images/user-noimage-small.png')); ?>" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                        <?php endif; ?>
                                        <div class="margin-left-85px">
                                            <a target="_blank" class="d-inline-block text-dark text-medium margin-right-20px" href="<?php echo e(url('/profile/'.$rating->userslug)); ?>"><?php echo e(ucfirst($rating->name)); ?> </a>
                                            <span class="text-extra-small">Date :  <a href="javascript:voide(0)" class="text-main-color"><?php echo e(date('F d, Y', strtotime($rating->created_at))); ?></a></span>
                                            <div class="rating">
                                                <ul>
                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <li class="<?php echo e(($rating->rating >= $i) ? 'active':''); ?>"></li>
                                                    <?php endfor; ?>
                                                </ul>
                                            </div>
                                            <p class="margin-top-15px text-grey-2"><?php echo e(ucfirst($rating->comment)); ?> </p>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="alert alert-danger">User have no reviews yet!</div>
                                <?php endif; ?>
                                
                            </ul>

                        </div>
                    </div>
                    <?php if(Auth::user() && $userdetails->id != Auth::user()->id && Auth::user()->type != 1): ?>
                    <div class="margin-bottom-30px box-shadow">
                        <div class="padding-30px background-white">
                            <h3><i class="far fa-star margin-right-10px text-main-color"></i> Add Review </h3>
                            <hr>
                            <div id="errorMsg" style="display: none;" class="alert alert-danger"></div>
                            <?php if(session()->has('message.level')): ?>
                            <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <?php echo session('message.content'); ?>

                            </div>
                            <?php endif; ?>
                            <form action="<?php echo e(url('/profile/'. Request::segment(2))); ?>" method="post" name="reviewSubmit" id="reviewSubmit" onsubmit="return chkFormdetails()">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="form-group row col-md-12">
                                        <div class="col-md-6">Your Rating  <small>( Click stars to rate) </small>: <sup class="requiredSup">*</sup></div>
                                        <div class="col-md-6 rating rateUser">
                                            <ul>
                                                <li data-rate="1" class=""></li>
                                                <li data-rate="2" class=""></li>
                                                <li data-rate="3" class=""></li>
                                                <li data-rate="4" class=""></li>
                                                <li data-rate="5" class=""></li>
                                            </ul>
                                            <div class="error"><?php echo e($errors->first('rateVal')); ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                                    <label>Comment <small>(minimum 20 characters required)</small>: <sup class="requiredSup">*</sup></label>
                                    <textarea class="form-control" id="usercomments" name="usercomments" rows="3" placeholder="Your Comments here" minlength="20"><?php echo e(old('usercomments')); ?></textarea>
                                    <div class="error"><?php echo e($errors->first('usercomments')); ?></div>
                                </div>
                                <input type="hidden" name="rateVal" id="rateVal" >
                                <input type="hidden" name="touser" id="" value="<?php echo e($userdetails->id); ?>">
                                <button type="submit" name="saveComments" id="saveComments" class="btn-sm btn-lg btn-block background-main-color text-white text-center font-weight-bold text-uppercase border-radius-10 padding-10px">Add Now !</button>
                            </form>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="margin-bottom-30px box-shadow addreviewContainerBox">
                        <div class="padding-30px background-white">
                            <h3><i class="far fa-star margin-right-10px text-main-color"></i> Add Review </h3>
                            <hr>
                            <div id="errorMsg" style="display: none;" class="alert alert-danger"></div>
                            <?php if(session()->has('message.level')): ?>
                            <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <?php echo session('message.content'); ?>

                            </div>
                            <?php endif; ?>
                            <form action="" method="post" name="reviewSubmit" id="reviewSubmit" onsubmit="">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="form-group row col-md-12">
                                        <div class="col-md-6">Your Rating  <small>( Click stars to rate) </small>: <sup class="requiredSup">*</sup></div>
                                        <div class="col-md-6 rating rateUser">
                                            <ul>
                                                <li data-rate="1" class=""></li>
                                                <li data-rate="2" class=""></li>
                                                <li data-rate="3" class=""></li>
                                                <li data-rate="4" class=""></li>
                                                <li data-rate="5" class=""></li>
                                            </ul>
                                            <div class="error"><?php echo e($errors->first('rateVal')); ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                                    <label>Comment <small>(minimum 20 characters required)</small>: <sup class="requiredSup">*</sup></label>
                                    <textarea class="form-control" id="usercomments" name="usercomments" rows="3" placeholder="Your Comments here" minlength="20"><?php echo e(old('usercomments')); ?></textarea>
                                    <div class="error"><?php echo e($errors->first('usercomments')); ?></div>
                                </div>
                                <a href="<?php echo e(url('/login')); ?>" name="saveComments" id="saveComments" class="btn-sm btn-lg btn-block background-main-color text-white text-center font-weight-bold text-uppercase border-radius-10 padding-10px">Signin to review or comment !</a>
                            </form>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-4">
                    <div class="background-second-color border-radius-10 margin-bottom-45px text-white box-shadow">
                        <h3 class="padding-lr-30px padding-top-20px"><i class="far fa-clock margin-right-10px"></i> Horario de consulta</h3>
                        <div class="padding-bottom-30px">
                            <ul class="padding-0px margin-0px">
                                <li class="padding-lr-30px padding-tb-10px">Lunes <span class="float-right">
                                    <?php echo e(($usertimings->monStatus == 1) ? str_replace('-', ' - ', $usertimings->monTiming) : 'Closed'); ?> </span></li>
                                <li class="padding-lr-30px padding-tb-10px ba-2">Martes <span class="float-right"><?php echo e(($usertimings->tueStatus == 1) ? str_replace('-', ' - ', $usertimings->tueTiming) : 'Closed'); ?></span></li>
                                <li class="padding-lr-30px padding-tb-10px">Miércoles <span class="float-right"><?php echo e(($usertimings->wedStatus == 1) ? str_replace('-', ' - ', $usertimings->wedTiming) : 'Closed'); ?></span></li>
                                <li class="padding-lr-30px padding-tb-10px ba-2">Jueves <span class="float-right"><?php echo e(($usertimings->thuStatus == 1) ? str_replace('-', ' - ', $usertimings->thuTiming) : 'Closed'); ?></span></li>
                                <li class="padding-lr-30px padding-tb-10px">Viernes  <span class="float-right"><?php echo e(($usertimings->friStatus == 1) ? str_replace('-', ' - ', $usertimings->friTiming) : 'Closed'); ?></span></li>
                                <li class="padding-lr-30px padding-tb-10px ba-2">Sábado  <span class="float-right"><?php echo e(($usertimings->satStatus == 1) ? str_replace('-', ' - ', $usertimings->satTiming) : 'Closed'); ?></span></li>
                                <li class="padding-lr-30px padding-tb-10px">Domingo    <span class="float-right"><?php echo e(($usertimings->sunStatus == 1) ? str_replace('-', ' - ', $usertimings->sunTiming) : 'Closed'); ?></span></li>
                            </ul>
                        </div>
                    </div>

                    <div class="background-white border-radius-10 margin-bottom-45px">
                        <div class="padding-25px">
                            <h3 class="margin-lr-20px"><i class="fas fa-search margin-right-10px text-main-color"></i> Search Filter</h3>
                            <!-- Listing Search -->
                            <div class="listing-search">
                                <form>
                                    <div class="keywords margin-bottom-20px">
                                        <input class="listing-form first border-radius-10" type="text" placeholder="Keywords..." value="">
                                    </div>
                                    <div class="regions margin-bottom-20px">
                                        <input class="listing-form border-radius-10" type="text" placeholder="All Regions" value="">
                                    </div>

                                    <div class="categories dropdown margin-bottom-20px">
                                        <a class="listing-form d-block border-radius-10" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">All Categories</a>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                            <button class="dropdown-item text-up-small" type="button">Doctors</button>
                                            <button class="dropdown-item text-up-small" type="button">Clinics</button>
                                            <button class="dropdown-item text-up-small" type="button">Pharmacies</button>
                                            <button class="dropdown-item text-up-small" type="button">Labs</button>
                                        </div>
                                    </div>
                                    <a class="listing-bottom background-dark box-shadow border-radius-10" href="#">Search Now</a>
                                </form>
                            </div>
                            <!-- // Listing Search -->
                        </div>
                    </div>


                    <div class="featured-categorey">
                        <div class="row">
                            <div class="col-6 margin-bottom-30px wow fadeInUp">
                                <a href="#" class="d-block border-radius-15 hvr-float hvr-sh2">
                                    <div class="background-main-color text-white border-radius-15 padding-30px text-center opacity-hover-7">
                                        <div class="icon margin-bottom-15px opacity-7">
                                            <img src="<?php echo e(asset('public/front')); ?>/assets/img/icon/categorie-1.png" alt="">
                                        </div>
                                        Doctors
                                    </div>
                                </a>
                            </div>
                            <div class="col-6 margin-bottom-30px wow fadeInUp" data-wow-delay="0.2s">
                                <a href="#" class="d-block border-radius-15 hvr-float hvr-sh2">
                                    <div class="background-main-color text-white border-radius-15 padding-30px text-center opacity-hover-7">
                                        <div class="icon margin-bottom-15px opacity-7">
                                            <img src="<?php echo e(asset('public/front')); ?>/assets/img/icon/categorie-2.png" alt="">
                                        </div>
                                        Clinics
                                    </div>
                                </a>
                            </div>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php if(Auth::user() && ($userdetails->id == Auth::user()->id || Auth::user()->type == 1)): ?>
<script>
    jQuery('.addreviewContainerBox').remove();
</script>
<?php endif; ?>
<script>
    var map, marker;
    function initMap(){
        var lat = '<?php echo e($userdetails->varylat); ?>';
        var lng = '<?php echo e($userdetails->varylng); ?>';
        var zoom = 11;
        if(lat == '' || lng == ''){
            lat = 23.634501;
            lat = -102.55278399999997;
            zoom = 5;
        }

        var title = '<?php echo e(ucfirst($userdetails->name)); ?>';
        var iconpath = "<?php echo e(asset('public/front')); ?>/assets/images/markericon.png";
        
        var myLatlng = new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
        geocoder = new google.maps.Geocoder();
        map = new google.maps.Map(document.getElementById('map_canvas'), {
            zoom: zoom,
            center: {lat: parseFloat(lat), lng: parseFloat(lng)},
            maxZoom: 14
        });

        var getLat = $('#latitude').val();
        var getLng = $('#longitude').val();
        if(getLat != '' && getLng != ''){
            marker = new google.maps.Marker({
                map: map,
                position: myLatlng,
                icon: iconpath,
                title: title
            });
        }
    }

    
    $(document).ready(function(){
        initMap();
        $('.rateUser li').click(function(){
            $('.rateUser li').removeClass('active');

            var getVal = $(this).attr('data-rate');
            $('#rateVal').val(getVal);
            $('.rateUser li').each(function(){
                var getVal2 = $(this).attr('data-rate');
                if(getVal2 <= getVal){
                    $(this).addClass('active');
                }
            });    
        });
    });

    function chkFormdetails(){
        var getRateVal = $('#rateVal').val();
        var getCOmments = $('#usercomments').val();
        if(getRateVal == 0 || getRateVal == '' || getCOmments == ''){
            $('#errorMsg').show().html('Please add <strong>Rating</strong> and <strong>Comments</strong> before submit!!').fadeOut(5000);
            return false;
        }
        return true;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>