<!DOCTYPE html>
<html lang="en">
<head>
<title>My Survey</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="<?php echo e(asset('public/front/css/bootstrap.css')); ?>" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo e(asset('public/front/css/bootstrap-responsive.css')); ?>" type="text/css" media="screen">    
<link rel="stylesheet" href="<?php echo e(asset('public/front/css/style.css')); ?>" type="text/css" media="screen">

<script type="text/javascript" src="<?php echo e(asset('public/front/js/jquery.js')); ?>"></script>  
<script type="text/javascript" src="<?php echo e(asset('public/front/js/jquery.easing.1.3.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front/js/superfish.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/front/js/jquery.ui.totop.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/front/js/jquery.caroufredsel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front/js/jquery.touchSwipe.min.js')); ?>"></script>

<script>
$(document).ready(function() {
    /////// icons
    //$(".social li").find("a").css({opacity:0.6});
    $(".social li a").hover(function() {
        $(this).stop().animate({opacity:0.6 }, 400, 'easeOutExpo');         
    },function(){
        $(this).stop().animate({opacity:1 }, 400, 'easeOutExpo' );         
    });

    //carufredsel
    $('#carousel1').carouFredSel({
        auto: {
            timeoutDuration: 40000                  
        },
        responsive: true,
        prev: '.prev',
        next: '.next',
        width: '100%',
        scroll: {
            items: 1,
            duration: 1000,
            easing: "easeOutExpo"
        },          
        items: {
            width: '1000',
            height: 'auto', //  optionally resize item-height             
            visible: {
                min: 1,
                max: 1
            }
        },
        mousewheel: false,
        swipe: {
            onMouse: true,
            onTouch: true
            }
    }); 



}); //
$(window).load(function() {
    //
    $('.banner .button0').hover(function(){
        //$(this).stop().css({'color':'#82be48'});
        $(this).siblings('.txt2').stop().css({'color':'#0d9cd1', 'text-decoration':'underline'});
        }, function(){
            //$(this).stop().css({'color':'#ababab'});
            $(this).siblings('.txt2').stop().css({'color':'#777777', 'text-decoration':'none'});                 
    });


}); //
</script>       
<!--[if lt IE 8]>
        <div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg"border="0"alt=""/></a></div>  
    <![endif]-->    

<!--[if lt IE 9]>
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>      
  <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
<![endif]-->
</head>

<body>
<div id="main">

<header>
<div class="container">
<div class="row">
<div class="span12 clearfix">
<div class="top1">
    <a href="<?php echo e(url('/')); ?>" class="logo" ><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a>
</div>  
<div class="top2">
<div class="search-form-wrapper clearfix">
    <!-- <form id="search-form" action="search.php" method="GET" accept-charset="utf-8" class="navbar-form" >
        <input type="text" name="s" value='Search' onBlur="if(this.value=='') this.value='Search'" onFocus="if(this.value =='Search' ) this.value=''">
        <a href="#" onClick="document.getElementById('search-form').submit()"></a>
    </form> -->
    &nbsp;
</div>

<div class="navbar navbar_">
    <div class="navbar-inner navbar-inner_">
        <a class="btn btn-navbar btn-navbar_" data-toggle="collapse" data-target=".nav-collapse_">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>
        <div class="nav-collapse nav-collapse_ collapse">
            <ul class="nav sf-menu clearfix">
                <li <?php echo e((Request::is('/') ? 'class=active' : '')); ?>><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a></li>               
                <?php if(Auth::user() ): ?>
                    <?php if(Auth::user() && Auth::user()->type == 1): ?>
                        <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
                    <?php else: ?>
                        <li <?php echo e((Request::is('user/add-new-survey') ? 'class=active' : '')); ?> ><a href="<?php echo e(url('/user/add-new-survey')); ?>"><i class="fa fa-plus"></i> New Point</a></li>
                        <li <?php echo e((Request::is('user/surveys-list') ? 'class=active' : '')); ?>><a href="<?php echo e(url('/user/surveys-list')); ?>"><i class="fa fa-list"></i> Submitted Points</a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(url('/logout')); ?>">Logout <i class="fa fa-sign-out "></i></a></li>
                <?php else: ?>
                    <li><a href="<?php echo e(url('/login')); ?>"><i class="fa fa-user"></i> Login</a></li>
                <?php endif; ?>
                
            </ul>
        </div>
    </div>
</div>






</div>
</div>  
</div>  
</div>  
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer>
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="bot clearfix">
                    <div class="bot1">
                    </div>  
                </div>
            <div class="copyright">Copyright © <?php echo e(date('Y')); ?>. All rights reserved.</div>
            </div>  
        </div>  
    </div>      
</footer>
    
</div>
<script type="text/javascript" src="<?php echo e(asset('public/front/js/bootstrap.js')); ?>"></script>
</body>
</html>