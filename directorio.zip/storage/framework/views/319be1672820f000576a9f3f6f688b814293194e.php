<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h3 style="color: #119fd3;font-size: 19px;line-height: 25px;" ><?php echo e(ucfirst($surveyData[0]->form_title)); ?></h3>
     
    
</div>
<div class="modal-body">
    <table cellspacing="5" cellpadding="5" class="table table-striped">
        <tr>
            <th>Question</th>
            <th>Answer</th>
        </tr>
        <?php $__currentLoopData = $surveyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(ucfirst($row->question_title)); ?></td>
            <td><?php echo e(ucfirst($row->optionvalue)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
   
    <div id="map_canvas" style="width: 48%;height: 200px;float:left;"></div>
    <?php if($surveyData && $surveyData[0]->photo): ?>
    <div class="" style="width:50%;float:left;">
        <img style="margin-left:3px;width: 100%;" src="<?php echo e(url('/').'/public/uploads/survey/'.$surveyData[0]->photo); ?>" alt="">
    </div>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>

<script>
var lat = <?php echo e($surveyData[0]->lat); ?>;
var lng = <?php echo e($surveyData[0]->lng); ?>;
var markericon = "<?php echo e(url('/public/front/images/marker.png')); ?>";
function initialize() {
    
    var latlng = new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
    
    map = new google.maps.Map(document.getElementById('map_canvas'), {
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        center: latlng,
        zoom: 14,
    });

    var marker = new google.maps.Marker({
        position: latlng,
        map: map,
        draggable: true,
        icon: markericon
    });
}
$(document).ready(function(){
    initialize();
});
</script>