<?php $__env->startSection('content'); ?>
<style>
#ajax-contact-form .control-label {
    display: block;
}
.form-horizontal .control-label {
    text-align: left;
    width: 100%;
}
#map_canvas{
    width: 100%;
    height: 300px;
}

.questionContainer {
    font-weight: bold;
}
.optionContainer {
    padding-left: 15px;
}

#ajax-contact-form input[type="radio"] {
    box-shadow: none;
}

#ajax-contact-form input{
    padding-top: 5px;
    padding-bottom: 5px;
    margin-top: 1px;
}
@media  screen and (max-device-width: 400px) {
  /* some CSS here */
  div.top1 {
    display: none;
  }
  div.search-form-wrapper{
    display: none;
  }
}


</style>

<div id="content">
    <div class="container">
        
        


        <div class="row">
            <?php if(session()->has('message.level')): ?>
            <div class="alert alert-<?php echo e(session('message.level')); ?>"> 
                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                <?php echo session('message.content'); ?>

            </div>
            <?php endif; ?>
            <div class="span12">
                <div id="fields">
                    <div class="text-center"><div style="color: #119fd3;font-size: 19px;line-height: 25px;"><?php echo e(($formData) ? $formData->form_title : 'No details'); ?></div></div>
                    <hr>
                    <div id="errorMsg" style="display: none;"></div>
                    <form id="ajax-contact-form" method="POST" class="form-horizontal" onsubmit="return checkvalidations();" action="<?php echo e(route('user.savesurveydetails')); ?>" enctype="multipart/form-data" files="true">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="row">
                            <div class="span6">
                                <?php if($questionData && count($questionData) > 0): ?>
                                <?php $__currentLoopData = $questionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="control-group">
                                    <label class="control-label questionContainer" for="inputName">(<?php echo e($loop->iteration); ?>.)&nbsp; <?php echo e(ucfirst($question->question_title)); ?></label>
                                    <div class="controls optionContainer">                    
                                        
                                    <?php if(isset($optionData[$question->id])): ?>
                                    <?php $__currentLoopData = $optionData[$question->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($rowOption->field_type == 'input'): ?>
                                            <input required type="text" class="span5" name="input_<?php echo e($formData->id); ?>_<?php echo e($question->id); ?>_<?php echo e($rowOption->id); ?>" value=""><br/>
                                        <?php else: ?>
                                            <input type="radio" name="radio_<?php echo e($formData->id); ?>_<?php echo e($question->id); ?>" value="<?php echo e($rowOption->field_title); ?>__<?php echo e($rowOption->id); ?>"> <?php echo e(ucfirst($rowOption->field_title)); ?><br/>
                                        <?php endif; ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </div>
                                </div>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>
                                    <div class="col-md-12 col-sm-12 col-xs-12 alert alert-danger text-center">No question available !!</div>
                                <?php endif; ?>
                                    
                                
                            </div>
                            <div class="span6">
                                <label class="control-label" for="">Locate the accurate point of this place on the map (<small>Click on map if to correct location if needed</small>):</label>
                                <div id="map_canvas"></div>

                                <div class="control-group span6">
                                    <label class="control-label" for="inputName">Latitude:</label>
                                    <div class="controls">                    
                                      <input class="span5" type="text" id="lat" name="lat" value="" required >
                                    </div>
                                </div>
                                <div class="control-group span6">
                                    <label class="control-label" for="inputName">Longitude:</label>
                                    <div class="controls">                    
                                      <input class="span5" type="text" id="lng" name="lng" value="" required >
                                    </div>
                                </div>
                                <div class="control-group span6">
                                    <label class="control-label" for="inputName">Take a photo of the location you are referring to:</label>
                                    <div class="controls">                    
                                      <!-- onchange="showMyImage(this)" -->
                                    <label class="">
                                        <input style="border:0px;display: block;" onchange="showMyImage(this)" accept="image/jpeg, image/png"  class="span3 " type="file" id="photo" name="photo" <?php echo e(($formData && $formData->photorequired == 1)?'required="required"':''); ?>  capture="camera" >
                                        <input type="hidden" id="photoData" name="photoData">
                                    </label>



                                    </div>
                                    <img id="thumbnil" style="width:90px;height:auto; margin-top:10px;display: none;"  src="" alt="image"/>
                                </div>
                            </div>
                            
                        </div>
                        <?php if($formData && $questionData && count($questionData) > 0): ?>
                        <div class="text-center"><button type="submit" name="submit" class="btn btn-info"><em></em>submit</button></div>
                        <?php endif; ?>
                    </form>
                </div>
                
            </div>
           
        </div>  

        <div class="hl1"></div>

        
    </div>
</div>

<script>
/*$(document).ready(function() {
  if (window.File && window.FileList && window.FileReader) {
    $("#photo").on("change", function(e) {
      var files = e.target.files,
        filesLength = files.length;
      for (var i = 0; i < filesLength; i++) {
        var f = files[i]
        var fileReader = new FileReader();
        fileReader.onload = (function(e) {
          var file = e.target; console.log(f.size/1024);
          $("#thumbnil").attr("src", e.target.result).show();
          $('#photoData').val(e.target.result);
          
        });
        fileReader.readAsDataURL(f);
      }
    });
  } else {
    alert("Your browser doesn't support to File API")
  }
});*/
function showMyImage(fileInput) {
    var files = fileInput.files;
    for (var i = 0; i < files.length; i++) {           
        var file = files[i];
        var imageType = /image.*/;     
        if (!file.type.match(imageType)) {
            continue;
        }           
        var img=document.getElementById("thumbnil");            
        img.file = file;    
        var reader = new FileReader();
        reader.onload = (function(aImg) { 
            return function(e) { 
                aImg.src = e.target.result; 
            }; 
        })(img);
        reader.readAsDataURL(file);
        $('#thumbnil').show();
    }    
}

function checkvalidations(){
    var chkInput = true;
    var chkInputText = $('input[type="text"]').each(function(){
        if($(this).val() == ''){
            chkInput = false;
        }
    });
    if(!chkInput){
        $('#errorMsg').show().html('<div class="alert alert-danger">Please add some value in input boxes in question!!</div>').fadeOut(6000);
        $('html, body').animate({
            scrollTop: $("#errorMsg").offset().top
        }, 300);
        return false;
    }

    var chkRadio = true;
    $('.optionContainer').each(function(){
        var chkRadioLength = $(this).find('input[type="radio"]').length;
        if(chkRadioLength > 0){
            checkCheckedRadio = $(this).find('input[type="radio"]:checked').length;
            if(checkCheckedRadio == 0){
                chkRadio = false;
            }
        }
    });

    if(!chkRadio){
        $('#errorMsg').show().html('<div class="alert alert-danger">At least one option must be selected in questions have options!!</div>').fadeOut(6000);
        $('html, body').animate({
            scrollTop: $("#errorMsg").offset().top
        }, 300);
        return false;
    }
    
    return true;
}

function sharelocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, shareLocErorOcured);
    } else {
        alert('Geolocation is not supported by this browser.');
    }
}
function showPosition(position) {
    setUserLocMarker(position.coords.latitude, position.coords.longitude);
}
function shareLocErorOcured(){
    $.getJSON('https://ipinfo.io/geo', function(response) { 
        var loc = response.loc.split(',');
        console.log(loc[0]);
        console.log(loc[1]);
        setUserLocMarker(loc[0], loc[1]);
        });  
}

function setUserLocMarker(lat, lng){
    if(userLocMarker){
        userLocMarker.setMap(null);
    }
    var latlng = new google.maps.LatLng(lat, lng);
    userLocMarker = new google.maps.Marker({
        position: latlng,
        map: map,
        draggable: true,
        icon: markericon
    });
    map.setCenter(latlng);
    $('input#lat').val(lat);
    $('input#lng').val(lng);
    google.maps.event.addListener(userLocMarker,'dragend',function(event) {
        $('input#lat').val(event.latLng.lat());
        $('input#lng').val(event.latLng.lng());
    });
}

var map, userLocMarker;
var markericon = "<?php echo e(url('/public/front/images/marker.png')); ?>";

function initialize() {
    
    var pyrmont = new google.maps.LatLng(40.351777, -98.898926);
    
    map = new google.maps.Map(document.getElementById('map_canvas'), {
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: pyrmont,
      zoom: 4,
    });
    
    var DivBtnContainer = document.createElement('div');
    DivBtnContainer.innerHTML +=    '<div id="mapBtnsContainer"><button type="button" style="margin-bottom:15px;" id="" class="btn btn-info btn-small"  onclick="sharelocation()">Share Location</button></div>';
    DivBtnContainer.index = 0;
    map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(DivBtnContainer);
    /********************/
    google.maps.event.addListener(map, 'click', function(event) {
        setUserLocMarker(event.latLng.lat(), event.latLng.lng());
    });
}
$(document).ready(function(){
    initialize();
});
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDL5Ae9Mv4lqPyQ1wD3NUhHkpmuX85DFo4&libraries=places,geometry"
></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>