<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/sb-admin.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.user.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <div class="content-wrapper">
        <div class="container-fluid overflow-hidden">
            <div class="row margin-bottom-90px margin-lr-10px sm-mrl-0px">
                <!-- Page Title -->
                <div id="page-title" class="padding-30px background-white full-width">
                    <div class="container">
                        <ol class="breadcrumb opacity-5">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Reviews</li>
                        </ol>
                        <h1 class="font-weight-300">Reviews : To me</h1>
                    </div>
                </div>
                <!-- // Page Title -->
                <div class="full-width row margin-tb-45px">

                    <!-- Review item -->
                    
                    <?php $__empty_1 = true; $__currentLoopData = $reviewsFromMe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-6 margin-bottom-45px">
                        <div class="background-white thum-hover box-shadow hvr-float">
                            <div class="padding-30px">
                                <?php if($rating->image): ?>
                                <img style="width: 60px;height: 60px;" src="<?php echo e(asset('public/uploads/userimage'.'/'.$rating->touserid.'/'.$rating->image)); ?>" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                <?php else: ?>
                                <img style="width: 60px;height: 60px;" src="<?php echo e(asset('public/front/assets/images/user-noimage-small.png')); ?>" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                <?php endif; ?>
                                
                                <div class="margin-left-85px">
                                    <?php if($rating->type == 2 || $rating->type == 3): ?>
                                    <a target="_blank" class="d-inline-block text-dark text-medium margin-right-20px" href="<?php echo e(url('/profile/'.$rating->userslug)); ?>"><?php echo e(ucfirst($rating->name)); ?> <small>( <?php if($rating->type == 2){ echo 'Doctor';}elseif($rating->type == 3){echo "Clinic";}else{ echo "Visitor"; }  ?> )</small> </a>
                                    <?php else: ?>
                                    <a target="_blank" class="d-inline-block text-dark text-medium margin-right-20px" href="javascript:void(0)"><?php echo e(ucfirst($rating->name)); ?> <small>( <?php echo "Visitor"; ?> )</small> </a>
                                    <?php endif; ?>
                                    
                                    <span class="text-extra-small">Date :  <a href="javascript:voide(0)" class="text-main-color"><?php echo e(date('F d, Y', strtotime($rating->created_at))); ?></a></span>
                                    <div class="rating">
                                        <ul>
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <li class="<?php echo e(($rating->rating >= $i) ? 'active':''); ?>"></li>
                                            <?php endfor; ?>
                                        </ul>
                                    </div>
                                    <p class="margin-top-15px text-grey-2"><?php echo e(ucfirst($rating->comment)); ?></p>
                                    <!-- <a href="#" class="d-inline-block text-grey-2 text-up-small"><i class="far fa-file-alt"></i> Edit</a>
                                    <a href="#" class="d-inline-block margin-lr-20px text-grey-2 text-up-small"><i class="far fa-window-close"></i> Delete</a> -->

                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12 alert alert-danger text-center">You have not received any reviews yet!</div>
                    <?php endif; ?>
                    
                    
                </div>

                <!-- pagination -->
                <!-- <ul class="pagination pagination-md">
                    <li class="page-item disabled"><a class="page-link rounded-0" href="#" tabindex="-1">Previous</a></li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link rounded-0" href="#">Next</a></li>
                </ul> -->
                <!-- //pagination -->

            </div>
        </div>
        <!-- /.container-fluid-->
        <!-- /.content-wrapper-->
        <footer class="sticky-footer">
            <div class="container">
                <div class="text-center">
                    <span>© 2018 tabib Health Directory | All Right Reserved <a class="text-grey-2 margin-left-15px" href="https://themeforest.net/user/nile-theme/portfolio" target="_blank">Powered by : Nile Theme</a></span>
                </div>
            </div>
        </footer>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
          <i class="fa fa-angle-up"></i>
        </a>
        <!-- Logout Modal-->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="page-login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>