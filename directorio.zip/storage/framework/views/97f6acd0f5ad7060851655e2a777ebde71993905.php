<?php $__env->startSection('content'); ?>

<div id="page-title" class="padding-tb-30px gradient-white">
        <div class="container text-center">
            <ol class="breadcrumb opacity-5">
                <li><a href="#">Home</a></li>
                <li class="active">Sing Up</li>
            </ol>
            <h1 class="font-weight-300">Sing Up Page</h1>
        </div>
    </div>

    <div class="container margin-bottom-100px">
        <!--======= log_in_page =======-->
        <div id="log-in" class="site-form log-in-form box-shadow border-radius-10">
    
            <div class="form-output">
                <?php if(session()->has('message.level')): ?>
                <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo session('message.content'); ?>

                </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('signup.registeruser')); ?>" name="registrationForm" id="registrationForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-group label-floating">
                        <label class="control-label">Full Name</label>
                        <input class="form-control" placeholder="Full Name" type="text" name="fullname" id="fullname" required maxlength="25" minlength="3" value="<?php echo e(old('fullname')); ?>" >
                        <div class="error"><?php echo e($errors->first('fullname')); ?></div>
                    </div>
                    <div class="form-group label-floating">
                        <label class="control-label">Your Email</label>
                        <input class="form-control" placeholder="Email" type="email" name="email" id="email" required value="<?php echo e(old('email')); ?>">
                        <div class="error"><?php echo e($errors->first('email')); ?></div>
                    </div>
                    <div class="form-group label-floating">
                        <label class="control-label">Your Password</label>
                        <input class="form-control" placeholder="" type="password" name="password" id="password" required maxlength="25" minlength="6" value="<?php echo e(old('password')); ?>" >
                        <div class="error"><?php echo e($errors->first('password')); ?></div>
                    </div>

                    <div class="form-group label-floating">
                        <label class="control-label">Confirm Your Password</label>
                        <input class="form-control" equalTo="#password" placeholder="" type="password" name="password_confirmation" id="password_confirmation" required maxlength="25" minlength="6" value="<?php echo e(old('password_confirmation')); ?>" >
                        <div class="error"><?php echo e($errors->first('password_confirmation')); ?></div>
                    </div>

                    <div class="form-group label-floating is-select">
                        <label class="control-label">Signup Yourself AS:</label>
                        <select class="selectpicker form-control" name="userSignupAs" id="userSignupAs" required >
                            <option value="4">Visitor</option>
                            <option value="2">Doctor</option>
                            <option value="3">Clinic</option>
                        </select>
                        <div class="error"><?php echo e($errors->first('userSignupAs')); ?></div>
                    </div>

                    <div class="remember">
                        <div class="checkbox">
                            <label>
                            <input name="optionsCheckboxes" type="checkbox" required >
                            I accept the <a href="#">Terms and Conditions</a> of the website
                        </label>
                        </div>
                    </div>

                    <button type="submit" name="submit" id="submit" class="btn btn-md btn-primary full-width">Complete sign up !</button>

                    <p>you have an account? <a href="page-login.html"> Sing in !</a> </p>
                </form>

            </div>
        </div>
        <!--======= // log_in_page =======-->

    </div>

<script>
    $(document).ready(function(){
        $('#registrationForm').validate();
    });    
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>