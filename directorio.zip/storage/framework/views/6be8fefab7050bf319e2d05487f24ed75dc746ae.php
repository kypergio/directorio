<?php $__env->startSection('content'); ?>
<div id="page-title" class="padding-tb-30px gradient-white">
        <div class="container text-center">
            <ol class="breadcrumb opacity-5">
                <li><a href="#">Home</a></li>
                <li class="active">Login</li>
            </ol>
            <h1 class="font-weight-300">Login Page</h1>
        </div>
    </div>

    <div class="container margin-bottom-100px">
        <!--======= log_in_page =======-->
        <div id="log-in" class="site-form log-in-form box-shadow border-radius-10">

            <div class="form-output">
                <?php if(session()->has('message.level')): ?>
                <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo session('message.content'); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->has('delete')): ?>
                <div class="alert alert-danger">
                    <strong><?php echo e($errors->first('delete')); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($errors->has('status')): ?>
                <div class="alert alert-danger">
                    <strong><?php echo e($errors->first('status')); ?></strong>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('login')); ?>" method="POST" name="loginForm" id="loginForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-group label-floating">
                        <label class="control-label">Your Email</label>
                        <input class="form-control" placeholder="Email" type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required autofocus >
                        <div class="error"><?php echo e($errors->first('email')); ?></div>
                    </div>
                    <div class="form-group label-floating">
                        <label class="control-label">Your Password</label>
                        <input class="form-control" placeholder="Password" type="password" name="password" id="password" required >
                        <div class="error"><?php echo e($errors->first('password')); ?></div>
                    </div>

                    <div class="remember">
                        <div class="checkbox">
                            <label>
                            <input name="remember" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?> >
                                Remember Me
                        </label>
                        </div>
                        <a style="display: none;" href="<?php echo e(url('password/reset')); ?>" class="forgot">Forgot my Password</a>
                    </div>

                    <button type="submit" name="submit" id="submit"  class="btn btn-md btn-primary full-width">Login</button>

                    <p>Don't you have an account? <a href="<?php echo e(url('register')); ?>">Register Now!</a> </p>
                </form>
            </div>
        </div>
        <!--======= // log_in_page =======-->

    </div>
<script>
    $(document).ready(function(){
        $('#loginForm').validate();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>