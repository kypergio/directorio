<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/bootstrap.min.css">
<style>
    .Content {
        max-width: 500px;
        margin: auto;
        border: 1px solid #dcdcdc;
        margin-top:10px;
        margin-bottom: 20px;
    }
    .btn-primary {
        background-color:#f1b434;
        border-color:#f1b434;
    }
    textarea:focus,
    input[type="text"]:focus,
    input[type="password"]:focus,
    input[type="datetime"]:focus,
    input[type="datetime-local"]:focus,
    input[type="date"]:focus,
    input[type="month"]:focus,
    input[type="time"]:focus,
    input[type="week"]:focus,
    input[type="number"]:focus,
    input[type="email"]:focus,
    input[type="url"]:focus,
    input[type="search"]:focus,
    input[type="tel"]:focus,
    input[type="color"]:focus,
    .uneditable-input:focus {   
      border-color: #f1b434;
      box-shadow: 0 1px 1px #f1b434 inset, 0 0 8px #f1b434;
      outline: 0 none;
    }
</style>
<div id="page-title" class="padding-tb-30px gradient-white">
        <div class="container text-center">
            <ol class="breadcrumb opacity-5 hidden">
                <li><a href="#"><?php echo app('translator')->getFromJson('labels.home'); ?></a></li>
                <li class="active"><?php echo app('translator')->getFromJson('labels.login'); ?></li>
            </ol>
            <h1 class="font-weight-300"><?php echo app('translator')->getFromJson('labels.login_page'); ?></h1>
        </div>
    </div>

    <div class="container margin-bottom-100px">
        <!--======= log_in_page =======-->
        <div id="log-in" class="site-form log-in-form box-shadow border-radius-10">

            <div class="form-output">
                <?php if(session()->has('message.level')): ?>
                <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo session('message.content'); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->has('delete')): ?>
                <div class="alert alert-danger">
                    <strong><?php echo e($errors->first('delete')); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($errors->has('status')): ?>
                <div class="alert alert-danger">
                    <strong><?php echo e($errors->first('status')); ?></strong>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('login')); ?>" method="POST" name="loginForm" id="loginForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-group label-floating">
                        <label class="control-label"><?php echo app('translator')->getFromJson('labels.youremail'); ?></label>
                        <input class="form-control" placeholder="<?php echo app('translator')->getFromJson('labels.email'); ?>" type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required autofocus >
                        <div class="error"><?php echo e($errors->first('email')); ?></div>
                    </div>
                    <div class="form-group label-floating">
                        <label class="control-label"><?php echo app('translator')->getFromJson('labels.yourpassword'); ?></label>
                        <input class="form-control" placeholder="<?php echo app('translator')->getFromJson('labels.password'); ?>" type="password" name="password" id="password" required >
                        <div class="error"><?php echo e($errors->first('password')); ?></div>
                    </div>

                    <div class="remember">
                        <div class="checkbox">
                            <label>
                            <input name="remember" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?> >
                                <?php echo app('translator')->getFromJson('labels.remember_me'); ?>
                        </label>
                        </div>
                        <a style="display: none;" href="<?php echo e(url('password/reset')); ?>" class="forgot">Forgot my Password</a>
                    </div>
                    <div style="text-align: center;">
                    <button type="submit" name="submit" id="submit"  class="btn btn-md btn-primary full-width"><?php echo app('translator')->getFromJson('labels.login'); ?></button>
                    </div>

                    <p><a style="color: #888;" target="_blank" href="<?php echo e(url('password/forget')); ?>">¿Olvidaste tu contraseña?</a> </p>
                </form>
            </div>
        </div>
        <!--======= // log_in_page =======-->

    </div>
<script>
    $(document).ready(function(){
        $('#loginForm').validate();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>