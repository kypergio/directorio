<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h3 style="font-size: 20px;font-size: 20px;line-height: 25px;"><?php echo e(ucfirst($surveyData[0]->form_title)); ?></h3>
</div>
<div class="modal-body">
    <div style="text-align: right;position:  absolute;right: 12px;margin-top: -34px;font-weight: bold;" >Point Number: <?php echo e($pointNumber); ?></div>
    <table cellspacing="5" cellpadding="5" class="table table-striped">
        <tr>
            <th>Question</th>
            <th>Answer</th>
        </tr>
        <?php $__currentLoopData = $surveyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(ucfirst($row->question_title)); ?></td>
            <td><?php echo e(ucfirst($row->optionvalue)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
   
    <div id="map_canvas2" style="width: 45%;height: 200px;float:left;"></div>
     <?php if($surveyData && $surveyData[0]->photo): ?>
    <div style="width:50%;float:left;">
        <img style="margin-left:3px;width: 100%;" src="<?php echo e(url('/').'/public/uploads/survey/'.$surveyData[0]->photo); ?>" alt="">
    </div>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>

<script>
var lat = <?php echo e($surveyData[0]->lat); ?>;
var lng = <?php echo e($surveyData[0]->lng); ?>;

function initialize2() {
    var markericon1 = "<?php echo e(url('/public/front/images/marker.png')); ?>";
    
    var latlng = new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
    
    var map2 = new google.maps.Map(document.getElementById('map_canvas2'), {
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        center: latlng,
        zoom: 14,
    });

    var marker = new google.maps.Marker({
        position: latlng,
        map: map2,
        icon: markericon1
    });
}
$(document).ready(function(){
    
        initialize2();
    
});
</script>