<?php $__env->startSection('content'); ?>
<div id="page-title" class="padding-tb-30px gradient-white">
        <div class="container text-center">
            <ol class="breadcrumb opacity-5">
                <li><a href="#">Home</a></li>
                <li class="active">About</li>
            </ol>
            <h1 class="font-weight-300">About</h1>
        </div>
    </div>


    <section class="margin-tb-100px">
        <div class="container">

            <div class="row">

                <div class="col-lg-3 col-md-6 sm-mb-30px wow fadeInUp">
                    <div class="service text-center opacity-hover-7 hvr-bob">
                        <div class="icon margin-bottom-10px">
                            <img src="assets/img/icon/service-1.png" alt="">
                        </div>
                        <h3 class="text-second-color">Reliable Places</h3>
                        <p class="text-grey-2">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 sm-mb-30px wow fadeInUp" data-wow-delay="0.2s">
                    <div class="service text-center opacity-hover-7 hvr-bob">
                        <div class="icon margin-bottom-10px">
                            <img src="assets/img/icon/service-2.png" alt="">
                        </div>
                        <h3 class="text-second-color">High Credibility</h3>
                        <p class="text-grey-2">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 sm-mb-30px wow fadeInUp" data-wow-delay="0.4s">
                    <div class="service text-center opacity-hover-7 hvr-bob">
                        <div class="icon margin-bottom-10px">
                            <img src="assets/img/icon/service-3.png" alt="">
                        </div>
                        <h3 class="text-second-color">Quick search</h3>
                        <p class="text-grey-2">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 sm-mb-30px wow fadeInUp" data-wow-delay="0.6s">
                    <div class="service text-center opacity-hover-7 hvr-bob">
                        <div class="icon margin-bottom-10px">
                            <img src="assets/img/icon/service-4.png" alt="">
                        </div>
                        <h3 class="text-second-color">Know better</h3>
                        <p class="text-grey-2">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>
                    </div>
                </div>

            </div>

        </div>
    </section>


    <section class="padding-tb-80px background-second-color">
        <div class="container">
            <div class="row">

                <div class="col-lg-3">
                    <div class="item text-white opacity-hover-7 hvr-bob border-right-1 wow fadeInUp">
                        <div class="opacity-hover-7 hvr-bob">
                            <div class="title margin-bottom-15px">
                                <h2> Unlimited Colors</h2>
                            </div>
                            <p class="opacity-5">Lorem ipsum dolor sit amet, no movet simul laoreet pri, aperiri fabulas expetenda ei pro.</p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3">
                    <div class="item text-white border-right-1 wow fadeInUp">
                        <div class="opacity-hover-7 hvr-bob">
                            <div class="title margin-bottom-15px">
                                <h2>Powerful Website</h2>
                            </div>
                            <p class="opacity-5">Lorem ipsum dolor sit amet, no movet simul laoreet pri, aperiri fabulas expetenda ei pro.</p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3">
                    <div class="item text-white border-right-1 wow fadeInUp">
                        <div class="opacity-hover-7 hvr-bob">
                            <div class="title margin-bottom-15px">
                                <h2>Responsive Design</h2>
                            </div>
                            <p class="opacity-5">Lorem ipsum dolor sit amet, no movet simul laoreet pri, aperiri fabulas expetenda ei pro.</p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3">
                    <div class="item text-white wow fadeInUp">
                        <div class="opacity-hover-7 hvr-bob">
                            <div class="title margin-bottom-15px">
                                <h2>High Speed</h2>
                            </div>
                            <p class="opacity-5">Lorem ipsum dolor sit amet, no movet simul laoreet pri, aperiri fabulas expetenda ei pro.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <section class="padding-tb-100px background-white">
        <!-- Section Title -->
        <div class="container padding-bottom-40px">
            <div class="row justify-content-center text-center">
                <div class="col-md-7">
                    <h2 class="text-grey-3 text-center">Our Clients</h2>
                    <div class="margin-tb-30px text-grey-3 opacity-6">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus deserunt, nobis quae eos provident quidem. Quaerat expedita dignissimos perferendis, nihil quo distinctio eius architecto reprehenderit maiores.
                    </div>
                </div>
            </div>
        </div>
        <!-- end Section Title -->

        <div class="container">
            <ul class="row clients-border no-gutters padding-0px margin-0px list-unstyled text-center">
                <li class="col-md-3 col-6 padding-tb-30px wow fadeInUp">
                    <a href="#" class="hvr-bounce-out"><img src="http://placehold.it/140x90" alt=""></a>
                </li>
                <li class="col-md-3 col-6 padding-tb-30px wow fadeInUp" data-wow-delay="0.2s">
                    <a href="#" class="hvr-bounce-out"><img src="http://placehold.it/140x90" alt=""></a>
                </li>
                <li class="col-md-3 col-6 padding-tb-30px wow fadeInUp" data-wow-delay="0.4s">
                    <a href="#" class="hvr-bounce-out"><img src="http://placehold.it/140x90" alt=""></a>
                </li>
                <li class="col-md-3 col-6 padding-tb-30px wow fadeInUp" data-wow-delay="0.6s">
                    <a href="#" class="hvr-bounce-out"><img src="http://placehold.it/140x90" alt=""></a>
                </li>
            </ul>
        </div>

    </section>

   


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>