<?php $__env->startSection('pagecontent'); ?>

<div class="page-title">
	<div class="title_left">
	  <h3>Update Option</h3>
	</div>
</div>
<div class="clearfix"></div>
<!--
<?php if(count($errors) > 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="horizontal-center alert alert-danger alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php echo e($error); ?>

</div>
<?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
-->

<?php if(session()->has('message.level')): ?>
<div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <?php echo session('message.content'); ?>

</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Option details update </h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <br />
          <div id="msgError"></div>
          <form id="demo-form2" method="POST" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(url('admin/option/'.$optionData->id)); ?>" onsubmit="return chkFormDetails();">
          	<input name="_method" type="hidden" value="PUT">
          	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

             <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="question-title">Question Title <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<select id="question-title" required="required" class="form-control col-md-7 col-xs-12" name="question-title">
						<option value="">Please select question</option>
						<?php $__currentLoopData = $questionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($row->id); ?>" <?php echo e(($row->id == $optionData->question_id) ? ' selected="selected"' : ''); ?>><?php echo e($row->question_title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<div class="error"><?php echo e($errors->first('question-title')); ?></div>
	            </div>
            </div>

            <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="question-title">Option Type <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<select id="option-type" required="required" class="form-control col-md-7 col-xs-12" name="option-type">
						<option value="">Please select type</option>
						<option value="input" <?php echo e(($optionData->field_type == 'input') ? ' selected="selected"' : ''); ?>>Input</option>
						<option value="radio" <?php echo e(($optionData->field_type == 'radio') ? ' selected="selected"' : ''); ?>>Radio button</option>
					</select>
					<div class="error"><?php echo e($errors->first('option-type')); ?></div>
	            </div>
            </div>


            <div class="form-group" id="optionLabelContainer" style="<?php echo e(($optionData->field_type == 'radio') ? 'display: block;' : 'display: none;'); ?>">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="option-lable">Option Lable <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<input type="text" id="option-lable" value="<?php echo e($optionData->field_title); ?>" class="form-control col-md-7 col-xs-12" name="option-lable">
					<div class="error"><?php echo e($errors->first('option-lable')); ?></div>
	            </div>
            </div>

            <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success">Update</button>
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>


<script type="text/javascript">
	$('#option-type').change(function(){
		var optType = $('#option-type').val();
		if(optType == 'radio'){
			$('#optionLabelContainer').show();
			$('#option-lable').show().val('');
		}else{
			$('#optionLabelContainer').hide();
			$('#option-lable').hide().val('');
		}
	});

	function chkFormDetails(){
		var optType = $('#option-type').val();
		if(optType == 'radio'){
			var getLabelVal = $('#option-lable').val();
			if(getLabelVal == ''){
				$('#msgError').show().html('<div class="alert alert-danger">Please add label value!</div>').fadeOut(5000);
				$('#option-lable').focus();
				return false;
			}
		}
		return true;
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>