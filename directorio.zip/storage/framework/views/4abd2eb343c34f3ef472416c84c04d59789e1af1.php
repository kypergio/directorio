<?php $__env->startSection('pagecontent'); ?>

<style>
    
#map_canvas{
    width: 100%;
    height: 600px;
}
</style>
<div class="page-title">
    <div class="title_left">
      <h3>Preview</h3>
    </div>
</div>
<div class="clearfix"></div>

<?php if(session()->has('message.level')): ?>
<div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <?php echo session('message.content'); ?>

</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <?php if(!$resultData): ?>
        <div class="alert alert-danger alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            No record found!
        </div>
        <?php else: ?>
        <div class="alert alert-info alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
             Records found: <strong><?php echo e(count($resultData)); ?></strong>
        </div>
        <?php endif; ?>
        
    </div>
    <div class=" row" style="margin:0px " >    
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="form-group">
                    <div id="map_canvas"></div>
                </div>
            </div>
    </div>
    
</div>


<div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog" aria-hidden="true" id="popupSurveyDetails">
    <div class="modal-dialog modal-md">
        <div class="modal-content"></div>
    </div>
</div> 

<script>
var base_url = "<?php echo e(url('/')); ?>";
var resultData = '<?php echo (isset($resultData) && count($resultData)>0) ? json_encode($resultData) : '';  ?>';
resultData = (resultData != '') ? JSON.parse(resultData): [];


var map, userLocMarker, bounds;
var markericon = "<?php echo e(url('/public/front/images/marker.png')); ?>";

function initialize() {
    bounds = new google.maps.LatLngBounds();
    var pyrmont = new google.maps.LatLng(40.351777, -98.898926);
    
    map = new google.maps.Map(document.getElementById('map_canvas'), {
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: pyrmont,
      zoom: 4,
    });
    
    setAllMarkers();
}

function setAllMarkers(){
    if(resultData.length > 0 && resultData != ''){
        var tmpCount = 0;
        for(i in resultData){ 
            tmpCount++;
            var lat = resultData[i].lat;
            var lng = resultData[i].lng;
            var uniqueSurveyId = resultData[i].uniqueSurveyId;
            
            var latlng = new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
            bounds.extend(latlng);
            var marker = new google.maps.Marker({
                position: latlng,
                map: map,
                icon: markericon,
                uniqueSurveyId: uniqueSurveyId,
                tmpCount :tmpCount
            });
            google.maps.event.addListener(marker, 'click', function() { 
                showDetailsInPopup(this.uniqueSurveyId, this.tmpCount);
            });
        }
        

        map.fitBounds(bounds);
    }
}

function showDetailsInPopup(surveyid, pointNumber){
    $.ajax({
        url: '<?php echo e(url('/admin/surveydetails')); ?>',
        type: 'POST',
        data: {
            surveyid: surveyid,
            pointNumber: pointNumber,
            _token: '<?php echo e(csrf_token()); ?>',
        },
        success: function (data){
            $('#popupSurveyDetails .modal-content').html(data);
            setTimeout(function(){
                $('#popupSurveyDetails').modal('show');
            }, 600);
        },
        error: function (data, textStatus, errorThrown) {
           // alert('Error Occurred');
        }
    });
}

$(document).ready(function(){
    initialize();
});
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDL5Ae9Mv4lqPyQ1wD3NUhHkpmuX85DFo4&libraries=places,geometry"
></script>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>