<?php $__env->startComponent('mail::layout'); ?>
<?php $__env->slot('header'); ?>
<?php $__env->startComponent('mail::header', ["url" => ""]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>
<p class="center">
    <img src="https://image.ibb.co/k5Hm2A/mail-logo.jpg" alt="">
</p>
<br/>

#¡Hola, Dr. <?php echo e($doctor["name"]); ?>!
<p class="center">Hemos recibido en la página web la siguiente solicitud de un cliente potencial interesado en el tratamiento de Ultherapy® y hablar con usted:</p>
**<?php echo e($cliente["getName"]); ?>**<br/>
**<?php echo e($cliente["getPhone"]); ?>**<br/>
**<?php echo e($cliente["getEmail"]); ?>**<br/><br/>
**<?php echo e($cliente["getOption"]); ?>**<br/>
<?php echo e($cliente["getDesc"]); ?><br/><br/>
Le sugerimos responderle en un lapso no mayor de 24 hrs. para mantener activo su interés.

¡Saludos!<br/>
*Equipo Ultherapy®*
<?php $__env->slot('footer'); ?>
<?php $__env->startComponent('mail::footer'); ?>
© 2018 Merz Pharma<br/>
<p style="float: left; color: #fff;">Aviso de Privacidad&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;Términos y Condiciones</p>
<p style="float: right; color: #fff;">
    <a href="http://instagram.com" target="_blank"><img src="http://www.108garage.com/wp-content/uploads/2016/07/6832133-0-instagram-6-xxl.png" style="width: 25px;" alt=""></a>
    &nbsp;&nbsp;&nbsp;
    <a href="http://facebook.com" target="_blank"><img src="http://teaola.com/wp-content/uploads/2017/08/fb-white-round-icon-reverse-circle.png" style="width: 25px;" alt=""></a>
</p>

<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
