<!DOCTYPE html>
<html lang="en-US">

<head>
    <title>My Directory</title>
    <meta name="author" content="My-Theme">
    <meta name="robots" content="index follow">
    <meta name="googlebot" content="index follow">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="keywords" content="directory, doctor, doctor directory, Health directory, listing, map, medical, medical directory, professional directory, reservation, reviews">
    <meta name="description" content="Health Care & Medical Services Directory">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<!---------------------->
<meta property="og:type" content="article" /> 
<meta property="og:title" content="Ultherapy" />
<meta property="og:description" content="Descripción" />
<meta property="og:image" content="link a logo" />
<meta property="og:url" content="http>//ultherapy.mx" />
<meta property="og:site_name" content="Ultherapy" />

<meta name="twitter:title" content="Ultherapy">
<meta name="twitter:description" content="Descripción">
<meta name="twitter:image" content="Link a logo">
<meta name="twitter:site" content="@ultherapy">
<meta name="twitter:creator" content="@ultherapy">
<!---------------------->








    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    <!-- animate -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/animate.css" />
    <!-- owl Carousel assets -->
    <link href="<?php echo e(asset('public/front')); ?>/assets/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo e(asset('public/front')); ?>/assets/css/owl.theme.css" rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/hover-min.css">
    <!-- flag icon -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/flag-icon.min.css">
    <!-- main style -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/style.css">
    <!-- colors -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/colors/main.css">
    <!-- elegant icon -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/elegant_icon.css">

    <?php echo $__env->yieldContent('styles'); ?>

    
    <!-- jquery library  -->
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/jquery-3.2.1.min.js"></script>

    <!-- Maps library  -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDL5Ae9Mv4lqPyQ1wD3NUhHkpmuX85DFo4&libraries=places"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/jquery.gomap-1.3.3.min.js"></script>

    <!-- fontawesome  -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <script>
        var base_url = '<?php echo e(url('/')); ?>';
    </script>
</head>

<body>

    <header class="background-white box-shadow">
        <div class="container header-in">
            
  
                <div class="row">
                    <div class="col-lg-2 col-md-12">
                        <a id="logo" href="<?php echo e(url('/')); ?>" class="d-inline-block margin-tb-15px"><img src="<?php echo e(asset('public/front')); ?>/assets/img/logo-1.png" alt=""></a>
                        <a class="mobile-toggle padding-13px background-main-color" href="#"><i class="fas fa-bars"></i></a>
                    </div>
                    <div class="col-lg-7 col-md-12 position-inherit">
                        <ul id="menu-main" class="nav-menu float-lg-right link-padding-tb-20px">
                            <li><a href="<?php echo e(url('')); ?>"><i class="fa fa-home"></i> Home</a></li>
                            <li><a href="<?php echo e(url('/about-us')); ?>"> About Us</a></li>
                            <li><a href="<?php echo e(url('/contact-us')); ?>">Conact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <?php if(Auth::user() ): ?>
                            <?php if(Auth::user() && Auth::user()->type == 1): ?>
                            <a href="<?php echo e(url('/admin')); ?>" class="btn btn-sm border-radius-30 margin-tb-15px text-white background-second-color  box-shadow float-right padding-lr-20px margin-left-20px">
                                <i class="fa fa-user"></i>  Dashboard
                            </a>
                            <div class="nav-item float-left">
                                <a href="<?php echo e(url('/logout')); ?>" class="nav-link margin-top-10px">
                                    <div class="text-grey-3"><i class="fa fa-fw fa-sign-out-alt"></i>Logout</div>
                                </a>
                            </div>
                            <?php else: ?>
                            <a href="<?php echo e(url('/mydashboard')); ?>" class="btn btn-sm border-radius-30 margin-tb-15px text-white background-second-color  box-shadow float-right padding-lr-20px margin-left-20px">
                                <i class="fa fa-user"></i>  Dashboard
                            </a>
                            <div class="nav-item float-left">
                                <a href="<?php echo e(url('/logout')); ?>" class="nav-link margin-top-10px" >
                                    <div class="text-grey-3"><i class="fa fa-fw fa-sign-out-alt"></i>Logout</div>
                                </a>
                            </div>
                            <?php endif; ?>

                        <?php else: ?>
                        <a href="<?php echo e(url('/login')); ?>" class="btn btn-sm border-radius-30 margin-tb-15px text-white background-second-color  box-shadow float-right padding-lr-20px margin-left-30px">
                          <i class="fa fa-user"></i>  Login
                        </a>
                        <a href="<?php echo e(url('/register')); ?>" class="padding-lr-0px margin-left-30px margin-tb-20px d-inline-block text-up-small float-left float-lg-right"><i class="far fa-user"></i>  Signup</a>&nbsp;
                        <?php endif; ?>
                        
                    </div>
                </div>
             
        </div>
    </header>
    <!-- // Header  -->
    
<?php echo $__env->yieldContent('content'); ?>

<?php if(Request::segment(1) != 'mydashboard'): ?>
    <footer class="padding-tb-100px background-main-color wow fadeInUp">
        <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <a class="d-inline-block margin-tb-15px"><img src="<?php echo e(asset('public/front')); ?>/assets/img/logo-2.png" alt=""></a>
                </div>
                <div class="col-lg-4">
                    <p class="text-white opacity-7">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                </div>
                <div class="col-lg-6">
                    <ul class="footer-menu margin-tb-15px margin-lr-0px padding-0px list-unstyled float-lg-right">
                        <li><a href="#" class="text-white">Featured</a></li>
                        <li><a href="#" class="text-white">Feedback</a></li>
                        <li><a href="#" class="text-white">Ask a Question</a></li>
                        <li><a href="#" class="text-white">Team</a></li>
                    </ul>
                </div>
            </div>
            <hr class="border-white opacity-4 margin-tb-45px">
            <div class="row">
                <div class="col-lg-6">
                    <p class="margin-0px text-white opacity-7 sm-mb-15px">© 2018 tabib Health Directory | All Right Reserved. </p>
                </div>
                <div class="col-lg-6">
                    <ul class="social-icon style-2 float-lg-right">
                        <li class="list-inline-item"><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li class="list-inline-item"><a class="youtube" href="#"><i class="fab fa-youtube"></i></a></li>
                        <li class="list-inline-item"><a class="linkedin" href="#"><i class="fab fa-linkedin"></i></a></li>
                        <li class="list-inline-item"><a class="google" href="#"><i class="fab fa-google-plus"></i></a></li>
                        <li class="list-inline-item"><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a class="rss" href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
<?php endif; ?>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/sticky-sidebar.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/YouTubePopUp.jquery.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/owl.carousel.min.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/imagesloaded.min.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/wow.min.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/custom.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/popper.min.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/bootstrap.min.js"></script>
    <script  src="<?php echo e(asset('public/front')); ?>/assets/js/jquery.validate.js"></script>
        
</body>

</html>
