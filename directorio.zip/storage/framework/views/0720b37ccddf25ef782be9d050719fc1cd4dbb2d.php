<?php $__env->startSection('content'); ?>

<div id="page-title" class="padding-tb-30px gradient-white">
        <div class="container text-center">
            <ol class="breadcrumb opacity-5">
                <li><a href="#"><?php echo app('translator')->getFromJson('labels.home'); ?></a></li>
                <li class="active"><?php echo app('translator')->getFromJson('labels.dashboard'); ?></li>
            </ol>
            <h1 class="font-weight-300"><?php echo app('translator')->getFromJson('labels.sign_up_page'); ?></h1>
        </div>
    </div>

    <div class="container margin-bottom-100px">
        <!--======= log_in_page =======-->
        <div id="log-in" class="site-form log-in-form box-shadow border-radius-10">
    
            <div class="form-output">
                <?php if(session()->has('message.level')): ?>
                <div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo session('message.content'); ?>

                </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('signup.registeruser')); ?>" name="registrationForm" id="registrationForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-group label-floating">
                        <label class="control-label"><?php echo app('translator')->getFromJson('labels.fullname'); ?></label>
                        <input class="form-control" placeholder="<?php echo app('translator')->getFromJson('labels.fullname'); ?>" type="text" name="fullname" id="fullname" required maxlength="25" minlength="3" value="<?php echo e(old('fullname')); ?>" >
                        <div class="error"><?php echo e($errors->first('fullname')); ?></div>
                    </div>
                    <div class="form-group label-floating">
                        <label class="control-label"><?php echo app('translator')->getFromJson('labels.youremail'); ?></label>
                        <input class="form-control" placeholder="<?php echo app('translator')->getFromJson('labels.email'); ?>" type="email" name="email" id="email" required value="<?php echo e(old('email')); ?>">
                        <div class="error"><?php echo e($errors->first('email')); ?></div>
                    </div>
                    <div class="form-group label-floating">
                        <label class="control-label"><?php echo app('translator')->getFromJson('labels.yourpassword'); ?></label>
                        <input class="form-control" placeholder="<?php echo app('translator')->getFromJson('labels.yourpassword'); ?>" type="password" name="password" id="password" required maxlength="25" minlength="6" value="<?php echo e(old('password')); ?>" >
                        <div class="error"><?php echo e($errors->first('password')); ?></div>
                    </div>

                    <div class="form-group label-floating">
                        <label class="control-label"><?php echo app('translator')->getFromJson('labels.yourpassword_confirm'); ?></label>
                        <input class="form-control" equalTo="#password" placeholder="<?php echo app('translator')->getFromJson('labels.yourpassword_confirm'); ?>" type="password" name="password_confirmation" id="password_confirmation" required maxlength="25" minlength="6" value="<?php echo e(old('password_confirmation')); ?>" >
                        <div class="error"><?php echo e($errors->first('password_confirmation')); ?></div>
                    </div>

                    <div class="form-group label-floating is-select d-none">
                        <label class="control-label"><?php echo app('translator')->getFromJson('labels.signup_yourself_as'); ?></label>
                        <select class="selectpicker form-control" name="userSignupAs" id="userSignupAs" required >
                            <option  value="4">Visitor</option>
                        </select>
                        <div class="error"><?php echo e($errors->first('userSignupAs')); ?></div>
                    </div>

                    <div class="remember">
                        <div class="checkbox">
                            <label>
                            <input name="optionsCheckboxes" type="checkbox" required >
                            <?php echo app('translator')->getFromJson('labels.accept_terms_text'); ?>
                        </label>
                        </div>
                    </div>

                    <button type="submit" name="submit" id="submit" class="btn btn-md btn-primary full-width"><?php echo app('translator')->getFromJson('labels.complete_signup'); ?></button>

                    <p><?php echo app('translator')->getFromJson('labels.you_have_an_account'); ?> <a href="page-login.html"> <?php echo app('translator')->getFromJson('labels.register_signin'); ?></a> </p>
                </form>

            </div>
        </div>
        <!--======= // log_in_page =======-->

    </div>

<script>
    $(document).ready(function(){
        $('#registrationForm').validate();
    });    
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>