<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/sb-admin.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.user.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

    <div class="content-wrapper">
        <div class="container-fluid overflow-hidden">
            <div class="row margin-bottom-90px margin-lr-10px sm-mrl-0px">
                
                
                <div class="col-xl-3 col-md-6 margin-bottom-30px">
                    <a href="<?php echo e(url('mydashboard/my-reviews/to-me')); ?>" class="d-block padding-30px background-lime box-shadow border-radius-10 hvr-float">
                        <h6 class="text-white margin-0px font-weight-400">
                            <i class="far fa-user text-icon-large margin-bottom-10px opacity-5 d-block"></i>
                            <span class="font-2 text-extra-large"><?php echo e($myReviews->reviewsTome); ?></span>
                            <span class="margin-left-10px"><?php echo app('translator')->getFromJson('labels.dashboard_reviews_to_me'); ?></span>
                        </h6>
                    </a>
                </div>

                <div class="col-xl-3 col-md-6 margin-bottom-30px">
                    <a href="<?php echo e(url('mydashboard/my-reviews')); ?>" class="d-block padding-30px background-amber box-shadow border-radius-10 hvr-float">
                        <h6 class="text-white margin-0px font-weight-400">
                            <i class="far fa-star text-icon-large margin-bottom-10px opacity-5 d-block"></i>
                            <span class="font-2 text-extra-large"><?php echo e($myReviews->reviewsFromme); ?></span>
                            <span class="margin-left-10px"><?php echo app('translator')->getFromJson('labels.dashboard_reviews_by_me'); ?></span>
                        </h6>
                    </a>
                </div>

                <div class="col-12" style="display: none;">

                    <div class="alert alert-info  margin-bottom-35px border-radius-10 padding-30px">
                        <strong>Success!</strong> Indicates a successful or positive action.
                        <hr>
                        <p class="margin-0px">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="margin-bottom-30px">
                                <div class="padding-30px background-white border-radius-20 box-shadow">
                                    <h3><i class="far fa-envelope-open margin-right-10px text-main-color"></i> Admin Message </h3>
                                    <hr>
                                    <textarea class="form-control" placeholder="Enter  Admin Message  here" id="exampleTextarea" rows="3"></textarea>
                                    <a href="#" class="btn btn-md border-0 border-radius-10 background-main-color padding-lr-20px text-white margin-tb-10px">Sent Now</a>
                                </div>
                            </div>

                            <!-- -->
                            <div class="margin-bottom-30px">
                                <div class="padding-30px background-white border-radius-20 box-shadow">
                                    <h3><i class="far fa-bell margin-right-10px text-main-color"></i> Latest Activities </h3>
                                    <hr>
                                    <ul class="commentlist padding-0px margin-0px list-unstyled text-grey-3 clearfix">
                                        <li class="border-bottom-1 border-grey-1 margin-bottom-20px">
                                            <div class="padding-bottom-15px">
                                                <a class="d-block text-grey-2" href="#">
                                        <img src="http://placehold.it/60x60" class="height-30px margin-right-5px border-radius-30" alt=""> 
                                        <span class="text-black">Adel Alseed</span> Liked the last comment you </a>
                                                <span class="text-extra-small text-grey-4 margin-left-40px">Date :  <a href="#" class="text-grey-2">July 15, 2016</a></span>
                                            </div>
                                        </li>
                                        <li class="border-bottom-1 border-grey-1 margin-bottom-20px">
                                            <div class="padding-bottom-15px">
                                                <a class="d-block text-grey-2" href="#">
                                        <img src="http://placehold.it/60x60" class="height-30px margin-right-5px border-radius-30" alt=""> 
                                        <span class="text-black">Adel Alseed</span> Liked the last comment you </a>
                                                <span class="text-extra-small text-grey-4 margin-left-40px">Date :  <a href="#" class="text-grey-2">July 15, 2016</a></span>
                                            </div>
                                        </li>
                                        <li class="border-bottom-1 border-grey-1 margin-bottom-20px">
                                            <div class="padding-bottom-15px">
                                                <a class="d-block text-grey-3" href="#">
                                        <img src="http://placehold.it/60x60" class="height-30px margin-right-5px border-radius-30" alt=""> 
                                        <span class="text-black">Adel Alseed</span> Liked the last comment you </a>
                                                <span class="text-extra-small text-grey-4 margin-left-40px">Date :  <a href="#" class="text-grey-2">July 15, 2016</a></span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="padding-bottom-15px">
                                                <a class="d-block text-grey-2" href="#">
                                        <img src="http://placehold.it/60x60" class="height-30px margin-right-5px border-radius-30" alt=""> 
                                        <span class="text-black">Adel Alseed</span> Liked the last comment you </a>
                                                <span class="text-extra-small text-grey-4 margin-left-40px">Date :  <a href="#" class="text-grey-2">July 15, 2016</a></span>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- -->
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <!-- -->
                            <div class="margin-bottom-30px">
                                <div class="padding-30px background-white border-radius-20 box-shadow">
                                    <h3><i class="far fa-star margin-right-10px text-main-color"></i> Latest Reviews </h3>
                                    <hr>
                                    <ul class="commentlist padding-0px margin-0px list-unstyled text-grey-3">
                                        <li class="border-bottom-1 border-grey-1 margin-bottom-20px">
                                            <img src="http://placehold.it/60x60" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                            <div class="margin-left-85px">
                                                <a class="d-inline-block text-dark text-medium margin-right-20px" href="#">Bakhita alrawi </a>
                                                <span class="text-extra-small">Date :  <a href="#" class="text-main-color">July 15, 2016</a></span>
                                                <div class="rating">
                                                    <ul>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                        <li></li>
                                                    </ul>
                                                </div>
                                                <p class="margin-top-15px text-grey-2">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
                                            </div>
                                        </li>
                                        <li class="border-bottom-1 border-grey-1 margin-bottom-20px">
                                            <img src="http://placehold.it/60x60" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                            <div class="margin-left-85px">
                                                <a class="d-inline-block text-dark text-medium margin-right-20px" href="#">Rabie Elkheir </a>
                                                <span class="text-extra-small">Date :  <a href="#" class="text-main-color">July 15, 2016</a></span>
                                                <div class="rating">
                                                    <ul>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                </div>
                                                <p class="margin-top-15px text-grey-2">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
                                            </div>
                                        </li>
                                        <li class="border-bottom-1 border-grey-1 margin-bottom-20px">
                                            <img src="http://placehold.it/60x60" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                            <div class="margin-left-85px">
                                                <a class="d-inline-block text-dark text-medium margin-right-20px" href="#">Adel Alsaeed </a>
                                                <span class="text-extra-small">Date :  <a href="#" class="text-main-color">July 15, 2016</a></span>
                                                <div class="rating">
                                                    <ul>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                        <li class="active"></li>
                                                    </ul>
                                                </div>
                                                <p class="margin-top-15px text-grey-2">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>


        </div>
        <!-- /.container-fluid-->
        <!-- /.content-wrapper-->
        <footer class="sticky-footer">
            <div class="container">
                <div class="text-center">
                    <span><?php echo app('translator')->getFromJson('labels.footer_copyright'); ?> </span>
                </div>
            </div>
        </footer>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
          <i class="fa fa-angle-up"></i>
        </a>
        <!-- Logout Modal-->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="page-login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>