<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.user.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <div class="content-wrapper">
        <div class="container-fluid overflow-hidden">
            <div class="row margin-bottom-90px margin-lr-10px sm-mrl-0px">
                <!-- Page Title -->
                <div id="page-title" class="padding-30px background-white full-width">
                    <div class="container">
                        <ol class="breadcrumb opacity-5">
                            <li><a href="<?php echo e(route("user.dashboard")); ?>">Inicio</a></li>
                            <li class="active">Reseñas hechas por mi</li>
                        </ol>
                        <h1 class="font-weight-300">Reseñas hechas por mi</h1>
                    </div>
                </div>
                <!-- // Page Title -->
                <div class="full-width row margin-tb-45px">

                    <!-- Review item -->
                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-6 margin-bottom-45px">
                        <div class="background-white thum-hover box-shadow hvr-float">
                            <div class="padding-30px">
                                <?php if($rating->to->image): ?>
                                <img style="width: 60px;height: 60px;" src="/uploads/userimage/<?php echo e($rating->touserid); ?>/<?php echo e($rating->to->image); ?>" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                <?php else: ?>
                                <img style="width: 60px;height: 60px;" src="/front/assets/images/noimagefound.png" class="float-left margin-right-20px border-radius-60 margin-bottom-20px" alt="">
                                <?php endif; ?>
                                
                                <div class="margin-left-85px">
                                    <a target="_blank" class="d-inline-block text-dark text-medium margin-right-20px" href="<?php echo e(url('/profile/'.$rating->userslug)); ?>"><?php echo e(ucfirst($rating->name)); ?></a>
                                    <span class="text-extra-small">Date :
                                        <a href="javascript:voide(0)" class="text-main-color">
                                            <?php echo e(date('F d, Y', strtotime($rating->created_at))); ?>

                                        </a>
                                    </span>
                                    <div class="rating">
                                        <ul>
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <li class="<?php echo e(($rating->rating >= $i) ? 'active':''); ?>"></li>
                                            <?php endfor; ?>
                                        </ul>
                                    </div>
                                    <p class="margin-top-15px text-grey-2"><?php echo e(ucfirst($rating->comment)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12 alert alert-danger text-center">Todavía no has hecho ninguna reseña</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>