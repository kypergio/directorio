<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>


<style>
div.dataTables_paginate  a.next {
    position: unset;
}
#ajax-contact-form .control-label {
    display: block;
}
.form-horizontal .control-label {
    text-align: left;
    width: 100%;
}
#map_canvas{
    width: 100%;
    height: 300px;
}

.questionContainer {
    font-weight: bold;
}
.optionContainer {
    padding-left: 15px;
}

#ajax-contact-form input[type="radio"] {
    box-shadow: none;
}

#ajax-contact-form input{
    padding-top: 5px;
    padding-bottom: 5px;
    margin-top: 1px;
}



</style>

<div id="content">
    <div class="container">
        <h4 style="color:#3a3a3a;margin:  0px;padding: 0px;">All submitted points</h4>
        <?php if(session()->has('message.level')): ?>
        <div class="alert alert-<?php echo e(session('message.level')); ?>"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <?php echo session('message.content'); ?>

        </div>
        <?php endif; ?>


        <div class="row">
            <div class="span12">
                <div id="fields">
                    <div id="errorMsg" style="display: none;"></div>
                    <table id="dataListing" class="table table-striped table-bordered"></table>
                </div>
                
            </div>
           
        </div>  

        <div class="hl1"></div>

        
    </div>
</div>



<div class="modal hide fade" id="popupPreviewForm">
  
</div>

<script>
var dataTable ;
$(document).ready(function() {  //$('#popupPreviewForm').modal('show');
    dataTable = $("#dataListing").DataTable( {
        "processing": true,
        "serverSide": true,
        "columns":[{ "title": "Point No.", "sortable": false}, { "title": "Survey Name", "sortable": true},{ "title": "Latitude", "sortable": false}, { "title": "Longitude", "sortable": false}, { "title": "Created at", "sortable": false}, { "title": "Action", "sortable": false}],
        "ajax":{
            url: '<?php echo e(url('/user/listSurveysDatatable')); ?>', // json datasource
            type: "POST",  // method  , by default get
            data: { _token: '<?php echo e(csrf_token()); ?>' },
            error: function(){  // error handling
                $(".dataListing-error").html("");
                $("#dataListing").append('<tbody class="dataListing-grid-error"><tr><th class="text-center alert alert-danger" colspan="6">No data found</th></tr></tbody>');
                $("#dataListing_processing").css("display","none");
            },
        }
    } );
} );

function previewForm(surveyid){
    $.ajax({
        url: '<?php echo e(url('/user/previewSurvey')); ?>',
        type: 'POST',
        data: {
            surveyid: surveyid,
            _token: '<?php echo e(csrf_token()); ?>',
        },
        success: function (data){
            $('#popupPreviewForm').html(data);
            setTimeout(function(){
                $('#popupPreviewForm').modal('show');
            }, 600);
        },
        error: function (data, textStatus, errorThrown) {
           // alert('Error Occurred');
        }
    });
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDL5Ae9Mv4lqPyQ1wD3NUhHkpmuX85DFo4&libraries=places,geometry"
></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>