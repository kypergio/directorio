<div class="">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel"><?php echo e(ucfirst($formData->form_title)); ?></h4>
    </div>
    <div class="modal-body row" style="margin:0px " >
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <?php if($questionData && count($questionData) > 0): ?>
                <?php $__currentLoopData = $questionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <label class="control-label col-md-12 col-sm-12 col-xs-12" for="form-title">(<?php echo e($loop->iteration); ?>.)&nbsp; <?php echo e(ucfirst($question->question_title)); ?></label>
                    <?php if(isset($optionData[$question->id])): ?>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                    <?php $__currentLoopData = $optionData[$question->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($rowOption->field_type == 'input'): ?>
                            <input type="text"  value="" class="form-control col-md-7 col-xs-12" name="input_<?php echo e($formData->id); ?>_<?php echo e($question->id); ?>_<?php echo e($rowOption->id); ?>" style="margin-top: 1px;"><br>
                        <?php else: ?>
                            <input type="radio"  value="" class="col-md-1 col-xs-1" name="input_<?php echo e($formData->id); ?>_<?php echo e($question->id); ?>_<?php echo e($rowOption->id); ?>"> <?php echo e(ucfirst($rowOption->field_title)); ?><br>
                        <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php else: ?>
                    <div class="col-md-12 col-sm-12 col-xs-12">&nbsp;&nbsp;No options selected !!</div>
                    <?php endif; ?>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php else: ?>
                <div class="col-md-12 col-sm-12 col-xs-12 alert alert-danger text-center">No question available !!</div>
                <?php endif; ?>

            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="form-group">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <img src="<?php echo e(url('/public/admin/images/MySurveyMap.png')); ?>" alt="" style="width: 100%">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-12 col-sm-12 col-xs-12" for="form-title">Latitude
                    </label>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <input type="text" id="lat"  value="" class="form-control col-md-7 col-xs-12" name="lat">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-12 col-sm-12 col-xs-12" for="form-title">Longitude
                    </label>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <input type="text" id="lng"  value="" class="form-control col-md-7 col-xs-12" name="lng">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
</div>