<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front')); ?>/assets/css/sb-admin.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.user.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <div class="content-wrapper">
        <div class="container-fluid overflow-hidden">
            <div class="row margin-bottom-90px margin-lr-10px sm-mrl-0px">
                <!-- Page Title -->
                <div id="page-title" class="padding-30px background-white full-width">
                    <div class="container">
                        <ol class="breadcrumb opacity-5">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">My Profile</li>
                        </ol>
                        <h1 class="font-weight-300">My Profile</h1>
                    </div>
                </div>
                <!-- // Page Title -->
                <div id="msgShow" class="col-md-12" style="display: none;"></div>
                <?php if(session()->has('message.level')): ?>
                <div class="col-md-12 horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo session('message.content'); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="col-md-12 alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="col-md-12 alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('user.changepasswordSave')); ?>" method="post" name="changepwd" id="changepwd" onsubmit="return chkPassword();" >
                <div class="row margin-tb-45px full-width">

                    <?php echo csrf_field(); ?>
                    <div class="col-md-8  offset-md-5">
                      <div class="row">
                          <div class="col-md-12 margin-bottom-20px">
                              <label><i class="far fa-user margin-right-10px"></i> Old Password <sup class="requiredSup">*</sup></label>
                              <input type="text" class="form-control form-control-sm" name="oldpwd" id="oldpwd" placeholder="Old Password" required value="" minlength="6" maxlength="25">
                              <div class="error"><?php echo e($errors->first('oldpwd')); ?></div>
                          </div>
                          <div class="col-md-12 margin-bottom-20px">
                              <label><i class="far fa-user margin-right-10px"></i> New Password <sup class="requiredSup">*</sup></label>
                              <input type="text" class="form-control form-control-sm" name="newpwd" id="newpwd" placeholder="New Password" required value="" minlength="6" maxlength="25">
                              <div class="error"><?php echo e($errors->first('newpwd')); ?></div>
                          </div>
                          <div class="col-md-12 margin-bottom-20px">
                              <label><i class="far fa-user margin-right-10px"></i> New Password Confirmation <sup class="requiredSup">*</sup></label>
                              <input type="text" class="form-control form-control-sm" equalTo="#newpwd" name="newpwd_confirmation" id="newpwd_confirmation" placeholder="New Password Confirmation" required value="" minlength="6" maxlength="25">
                              <div class="error"><?php echo e($errors->first('newpwd_confirmation')); ?></div>
                          </div>
                          
                      </div>
                      <div class="col-md-12 text-center margin-top-20px">
                        <button class="btn btn-md padding-lr-25px  text-white background-main-color btn-inline-block" type="submit" name="submit" id="submit">Update Password</button>
                      </div>
                      <hr class="margin-tb-40px">
                      

                    </div>
                </div>
                </form>

            </div>
        </div>
        <!-- /.container-fluid-->
        <!-- /.content-wrapper-->
        <footer class="sticky-footer">
            <div class="container">
                <div class="text-center">
                    <span>© 2018 tabib Health Directory | All Right Reserved <a class="text-grey-2 margin-left-15px" href="https://themeforest.net/user/nile-theme/portfolio" target="_blank">Powered by : Nile Theme</a></span>
                </div>
            </div>
        </footer>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
          <i class="fa fa-angle-up"></i>
        </a>
        <!-- Logout Modal-->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="page-login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function(){
        $('#changepwd').validate();
    });
    function chkPassword(){
        if(!$('#changepwd').valid()){ return false;}

        var oldpwd = $('#oldpwd').val();
        var newpwd = $('#newpwd').val();
        var newpwdConfirm = $('#newpwd_confirmation').val();
        if(oldpwd == newpwd){
            $('#msgShow').show().html('<div class="alert alert-danger">The new password must be different from old password!</div>').fadeOut(5000);
            return false;
        }
        if(newpwd !== newpwdConfirm ){
            $('#msgShow').show().html('<div class="alert alert-danger">The new password must be equal to new password confirmation!</div>').fadeOut(5000);
            return false;
        }
        return true;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>