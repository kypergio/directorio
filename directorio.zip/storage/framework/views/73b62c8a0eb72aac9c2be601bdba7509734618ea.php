<?php $__env->startSection('pagecontent'); ?>

<style>
    
#map_canvas{
    width: 100%;
    height: 300px;
}
</style>
<div class="page-title">
    <div class="title_left">
      <h3>Preview</h3>
    </div>
</div>
<div class="clearfix"></div>

<?php if(session()->has('message.level')): ?>
<div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <?php echo session('message.content'); ?>

</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
    </div>

    


   




    <div class="">
        <div class="modal-body row" style="margin:0px " >
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <?php if($questionData && count($questionData) > 0): ?>
                    <?php $__currentLoopData = $questionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label class="control-label col-md-12 col-sm-12 col-xs-12" for="form-title">(<?php echo e($loop->iteration); ?>.)&nbsp; <?php echo e(ucfirst($question->question_title)); ?></label>
                        <?php if(isset($optionData[$question->id])): ?>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <?php $__currentLoopData = $optionData[$question->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rowOption->field_type == 'input'): ?>
                                <input type="text"  value="" class="form-control col-md-7 col-xs-12" name="input_<?php echo e($formData->id); ?>_<?php echo e($question->id); ?>_<?php echo e($rowOption->id); ?>" style="margin-top: 1px;"><br>
                            <?php else: ?>
                                <input type="radio"  value="" class="col-md-1 col-xs-1" name="input_<?php echo e($formData->id); ?>_<?php echo e($question->id); ?>_<?php echo e($rowOption->id); ?>"> <?php echo e(ucfirst($rowOption->field_title)); ?><br>
                            <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <?php else: ?>
                        <div class="col-md-12 col-sm-12 col-xs-12">&nbsp;&nbsp;No options selected !!</div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php else: ?>
                    <div class="col-md-12 col-sm-12 col-xs-12 alert alert-danger text-center">No question available !!</div>
                    <?php endif; ?>

                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <div id="map_canvas"></div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-12 col-sm-12 col-xs-12" for="form-title">Latitude
                        </label>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <input type="text" id="lat"  value="" class="form-control col-md-7 col-xs-12" name="lat">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-12 col-sm-12 col-xs-12" for="form-title">Longitude
                        </label>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <input type="text" id="lng"  value="" class="form-control col-md-7 col-xs-12" name="lng">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-12 col-sm-12 col-xs-12" for="form-title">Upload photo
                        </label>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <input accept="image/*" class="span5" type="file" id="photo" name="photo" <?php echo e(($formData && $formData->photorequired == 1)?'required="required"':''); ?>  >
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
    </div>
</div>

<script>
    function sharelocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, shareLocErorOcured);
    } else {
        alert('Geolocation is not supported by this browser.');
    }
}
function showPosition(position) {
    setUserLocMarker(position.coords.latitude, position.coords.longitude);
}
function shareLocErorOcured(){
    $.getJSON('https://ipinfo.io/geo', function(response) { 
        var loc = response.loc.split(',');
        console.log(loc[0]);
        console.log(loc[1]);
        setUserLocMarker(loc[0], loc[1]);
        });  
}

function setUserLocMarker(lat, lng){
    if(userLocMarker){
        userLocMarker.setMap(null);
    }
    var latlng = new google.maps.LatLng(lat, lng);
    userLocMarker = new google.maps.Marker({
        position: latlng,
        map: map,
        draggable: true,
        icon: markericon
    });
    map.setCenter(latlng);
    $('input#lat').val(lat);
    $('input#lng').val(lng);
    google.maps.event.addListener(userLocMarker,'dragend',function(event) {
        $('input#lat').val(event.latLng.lat());
        $('input#lng').val(event.latLng.lng());
    });
}

var map, userLocMarker;
var markericon = "<?php echo e(url('/public/front/images/marker.png')); ?>";

function initialize() {
    
    var pyrmont = new google.maps.LatLng(41.066928, -101.425782);
    
    map = new google.maps.Map(document.getElementById('map_canvas'), {
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: pyrmont,
      zoom: 4,
    });
    
    var DivBtnContainer = document.createElement('div');
    DivBtnContainer.innerHTML +=    '<div id="mapBtnsContainer"><button type="button" style="margin-top:5px;" id="" class="btn btn-info btn-small"  onclick="sharelocation()">Share Location</button></div>';
    DivBtnContainer.index = 0;
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(DivBtnContainer);
    /********************/
    google.maps.event.addListener(map, 'click', function(event) {
        setUserLocMarker(event.latLng.lat(), event.latLng.lng());
    });
}
$(document).ready(function(){
    initialize();
});
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDL5Ae9Mv4lqPyQ1wD3NUhHkpmuX85DFo4&libraries=places,geometry"
></script>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>