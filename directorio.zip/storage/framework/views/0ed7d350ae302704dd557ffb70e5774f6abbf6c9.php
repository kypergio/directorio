<?php $__env->startSection('pagecontent'); ?>

<div class="page-title">
  <div class="title_left">
    <h3>Restablece tu nombre</h3>
  </div>
</div>
<div class="clearfix"></div>
<!--
<?php if(count($errors) > 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="horizontal-center alert alert-danger alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php echo e($error); ?>

</div>
<?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
-->

<?php if(session()->has('message.level')): ?>
<div class="horizontal-center alert alert-<?php echo e(session('message.level')); ?>"> 
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <?php echo session('message.content'); ?>

</div>
<?php endif; ?>


<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Detalles </h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <br />
          <form onsubmit="return chkConfirm()" id="changeUsernameForm" method="POST" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(route('admin.changeusername')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="oldpwd">Nuevo nombre de usuario <span class="required">*</span>
                    <br>
                    <small>(Email address)</small>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="email" id="newusername" required="" value="<?php echo e(old('newusername')); ?>" class="form-control col-md-7 col-xs-12" name="newusername">
                    <div class="error"><?php echo e($errors->first('newusername')); ?></div>
                </div>
            </div>
            
            <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success">Enviar</button>
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>

<script>
jQuery(document).ready(function(){
    $('form#changeUsernameForm').validate();
});
function chkConfirm(){
    if($('form#changeUsernameForm').valid()){
        if(confirm('¿Estás seguro de que estás cambiando el correo electrónico del administrador?')){
            return true;
        }
    }
    return false;
}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>